<?php 



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<center><title>Sistema de Registros</title></center>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/w3.css">
	<link rel="stylesheet" href="css/sgi.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/glDatePicker.default.css" />
	<link rel="stylesheet" href="css/glDatePicker.jucees.css" />
	
</head>
<body>
	<!-- Top container -->
	<div class="w3-container w3-top w3-black w3-large w3-padding" style="z-index:4">
		<button class="w3-btn w3-hide-large w3-padding-0 w3-hover-text-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
		<span class="w3-right">Sistema de Registros</span>
	</div>
	
	<?php include 'menu.php'; ?>


	<!-- !PAGE CONTENT! -->
	<div class="w3-main" style="margin-left:300px;margin-top:43px;">

	<hr>
	<a href="formulario_cliente.php" role="button" class="btn btn-dark">Novo Atendimento</a>
	<!-- Footer -->
	<footer class="w3-container w3-padding-16 w3-light-grey">
		</footer>
	</div>
  		
		<script src="js/sidenav.js"></script>
	</div><!-- End page content -->



</body>

</html>