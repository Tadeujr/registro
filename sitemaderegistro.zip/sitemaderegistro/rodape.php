			<!-- Footer -->
			<footer class="w3-container w3-padding-16 w3-light-grey">
				<h4>FOOTER - Adaptado a Equipe RedeSim JUCEES</h4>
				<p>Powered by <a href="http://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
			</footer>
  		</div>
  		
		<script src="js/sidenav.js"></script>
	</div><!-- End page content -->