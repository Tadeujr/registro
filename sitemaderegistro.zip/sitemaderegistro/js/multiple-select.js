/**
 * Objeto que mapeia, para cada elemento select, as opções selecionadas no momento
 */
var multipleOptions = {};

/**
 * Permite a seleção de múltiplas opções em um único select 
 * 
 * @param selectId Id do elemento select
 * @param divId    Id do elemento div onde serão dispostas as informações dos elementos já selecionados
 * @param inputId  Id do elemento input que será enviado no formulário com os valores de todos as opções selecionadas
 */
function multipleSelect(selectId, divId, inputId) {
	var select = document.getElementById(selectId);
	var div = document.getElementById(divId);
	var input = document.getElementById(inputId);
	var separator = '-';
	
	multipleOptions[selectId] = [];
	
	var optionsSelected = multipleOptions[selectId];
		
	div.style['font-size'] = '0.8em';
	div.style['padding-left'] = '20px';
		
	div.appendChild(document.createElement('ul'));

	select.onchange = function() {
		var option = this.options[this.selectedIndex];
		if (this.selectedIndex > 0 && optionsSelected.indexOf(option.value) === -1)
			addSelectedOption(option);
	}
		
	function addSelectedOption(option) {
		var element = document.createElement('li');
		var delButton = createDelButton(option);

		element.appendChild(document.createTextNode(option.innerHTML));
		element.appendChild(delButton);
		
		div.appendChild(element);
		
		if (input.value)
			input.value += separator;
		input.value += option.value;
		
		optionsSelected.push(option.value);
	}
	
	function createDelButton(option) {
		var delButton = document.createElement('span');
		delButton.style['font-weight'] = 'bold';
		delButton.style['color'] = 'red';
		delButton.style['cursor'] = 'pointer';
		delButton.innerHTML = " X";
		
		delButton.onclick = function() {
			var element = this.parentNode;
			element.parentNode.removeChild(element);
			
			optionsSelected.splice(optionsSelected.indexOf(option.value), 1);
			input.value = optionsSelected.join(separator);
		}
		
		return delButton;
	}
}