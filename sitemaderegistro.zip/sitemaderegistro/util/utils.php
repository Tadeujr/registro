<?php

//Metodo que recebe um array a cria uma tabela  dinamicamente

function constroi_tabela($array){
	if (count($array) <= 0)
		return false;
	
    // start table

    $html = '<br /><br /><div class="w3-container">'
            . '<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">';
    // header row

    $html .= '<thead><tr>';
        foreach($array[0] as $key=>$value){           
            $html .= '<th>' . $key . '</th>';
        }

    $html .= '</tr></thead>';

    // data rows
    $html .= '<tbody>';
    foreach( $array as $key=>$value){
        $html .= '<tr>';
        foreach($value as $key2=>$value2){            
            $html .= '<td>' . $value2 . '</td>';
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';

    // finish table and return it
    $html .= '</div></table>';
    
    return $html;
}

// M�todo que salva alerta em sess�o para ser exibido na pr�xima tela
// Possiveis valores para $tipoAlerta: 'sucesso', 'aviso', 'erro'

function salvarAlertaSessao($tipoAlerta, $mensagem, $nomeTela) {
	$_SESSION['alerta'][$nomeTela] = array(
		'mensagem' => $mensagem,
		'tipo' => $tipoAlerta
	);
}

// Caso exista um alerta em sess�o para aquela tela, o exibe
function exibirAlertaSessao($nomeTela) {
	if (isset($_SESSION['alerta'])) {
		if (isset($_SESSION['alerta'][$nomeTela])) {
			exibirAlerta($_SESSION['alerta'][$nomeTela]['tipo'], $_SESSION['alerta'][$nomeTela]['mensagem']);
			unset($_SESSION['alerta'][$nomeTela]);
		}
	}
}

function exibirAlerta($tipoAlerta, $mensagem) {
	$cor = getCorAlerta($tipoAlerta);
	echo
	"<div class='w3-row-padding' id='alerta'>".
		"<div class='w3-container w3-round w3-card-8 w3-margin w3-{$cor}'>".
			"<span class='w3-closebtn' onclick='this.parentElement.style.display=\"none\"'>x</span>".
			"<p>{$mensagem}</p>".	
		"</div>".
	"</div>";
}

function getCorAlerta($tipoAlerta) {
	switch ($tipoAlerta) {
		case 'sucesso':
			$cor = 'green';
			break;
		case 'aviso':
			$cor = 'orange';
			break;
		case 'erro':
			$cor = 'red';
			break;
		default:
			$cor = 'blue';
	}
	return $cor;
}

?>