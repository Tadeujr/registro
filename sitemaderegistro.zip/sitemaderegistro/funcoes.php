<?php 
	date_default_timezone_set('America/Sao_Paulo');
	
	include 'conexao.php';
	

#------------------------------------------------------------------------------------------------------------------------------------------------
	#função retorna o horario do atendimento
	# para inserir a hora de entrada 
	function horaAtendimento(){
		return $data = date("H:i:s "); 
	}	
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função lista os clientes do sistema
	#retorna uma matriz com todos os clientes
	#usar para o relatório
	function listarClientes($conexao){
		$banco = mysqli_query($conexao, "select protocolo.protocolo,pessoa.nome, DATE_FORMAT(protocolo.periodo,'%d/%m/%Y') as 'data' 
		,protocolo.duvida,protocolo.solucao,protocolo.inicio,protocolo.fim from pessoa inner join cliente on (pessoa.pessoa_id = cliente.pessoa_fid) inner join 
		protocolo on (protocolo.cliente_fid = cliente.cliente_id)");
		
		$saida = [];
		$clientes = [];
		$i = 0;
		
		while($clientes= mysqli_fetch_array($banco)){
			array_push($saida,$clientes);
			
			
		}
		
		return $saida;
   }
   
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função busca um determinado cliente  do sistema
	# o retorno e um vetor
	function buscarProtocolo($conexao,$protocolo){
		$banco = mysqli_query($conexao,"select protocolo.protocolo,pessoa.nome, DATE_FORMAT(protocolo.periodo,'%d/%m/%Y') as 'data' 
		,protocolo.duvida,protocolo.solucao,protocolo.inicio,protocolo.fim from pessoa inner join cliente on (pessoa.pessoa_id = cliente.pessoa_fid) inner join 
		protocolo on (protocolo.cliente_fid = cliente.cliente_id) where protocolo.protocolo = '$protocolo'"); 
		$cliente = [];
		
		$cliente= mysqli_fetch_array($banco);
	
		return $cliente;
   }
    
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função adiciona na tabela pessoa, so precisa do nome pq o id prenche sozinho
	# lembra de fazer uma função para buscar o nome e retornar o id, para adicionar no protocolo, cliente ou usuario 
	function addPessoa($conexao,$nome){
		$banco = mysqli_query($conexao, "INSERT INTO `pessoa`(`nome`)values ('$nome')");
		$saida = [];
		
		$id_pessoa = mysqli_query($conexao, "select pessoa_id from pessoa where nome = '$nome'");
		$saida= mysqli_fetch_array($id_pessoa);
		
		return $saida[0];
   }
   
#------------------------------------------------------------------------------------------------------------------------------------------------
 
	#função adicionar adiciona na tabela cliente
	#addCliente($conexao, addPessoa($conexao,$nome))
	function addCliente($conexao,$id_pessoa){
		$banco = mysqli_query($conexao, "INSERT INTO `cliente`(`pessoa_fid`) values ('$id_pessoa')");
		
		$saida = [];
		
		$id_cliente = mysqli_query($conexao, "SELECT `cliente_id` FROM cliente where pessoa_fid = '$id_pessoa'");
		$saida= mysqli_fetch_array($id_cliente);
		return $saida[0];
	
		
   }
 
 #----------------------------------------------------------------------------------------------------------------------------------------------------
	#função busca o id da pessoa na tabela pessoa atraves do nome
	#
	function buscaPessoa($conexao,$nome){
		$banco = mysqli_query($conexao, "select pessoa_id from pessoa where nome = '$nome'");
		$saida = [];
		$saida= mysqli_fetch_array($banco);
		
		return $saida[0];		
	}

#------------------------------------------------------------------------------------------------------------------------------------------------
	/*PRIMEIRO CHAMAR A FUNÇÃO DE ADICIONAR PESSOA 
	DEPOIS BUSCAR PESSOA VAI RETORNAR O ID
	E POR ULTIMO EU CADASTRO COM LOGIN E SENHA
	*/
	#função adicionar adiciona na tabela Usuario
	#addUsuário($conexao, addPessoa($conexao,$nome)) LEMBRAR DE POR LOGIN E SENHA 
	function addUsuario($conexao,$nome,$login,$senha){
		$usuario_id = addPessoa($conexao,$nome);
		$hash = password_hash($senha, PASSWORD_DEFAULT);
		$banco = mysqli_query($conexao, "INSERT INTO `usuario`(`login`, `senha`, `pessoa_fid`) VALUES ('$login','$hash','$usuario_id')");
		
		
   }
   
   function login($conexao, $user,$senha){
	   $banco = mysqli_query($conexao, "SELECT * FROM usuario WHERE login = '$user'");
	   $hash = [];
	   $hash= mysqli_fetch_array($banco);
	   
	   if(password_verify($senha,$hash[1]) && $hash[0] != NULL 	){
		   return True;
	   }else{
		   return False;
	   }
	  
	  
	   
   }
 
 #------------------------------------------------------------------------------------------------------------------------------------------------
 
	#função adicionar adiciona na tabela cliente
	function verificarProtocolo($conexao){
		$protocolo = randomNum();
		$banco = mysqli_query($conexao, "select protocolo_id from protocolo like '$protocolo'");
		
		
		// enquanto nao achar um protocolo valido é criado um novo
		while($banco != NULL){
			$protocolo = randomNum();
			$banco = verificarProtocolo($conexao,$protocolo);
		}
		
		return $protocolo;#retorno para mostrar na tela e salvar no banco
		
   }
   # so para mostrar o protocolo na tela
   # chamar a função para testa o protocolo e mostra na tela
   function mostrarProtocolo($protocolo){
	
	   echo $protocolo;
   }
 
#------------------------------------------------------------------------------------------------------------------------------------------------
 
	#função  adiciona na tabela protocolo
	function protocolo($conexao,$duvida,$solucao ,$protocolo_id,$cliente_id,$inicio){
		$entrada = mysqli_query($conexao, "INSERT INTO `protocolo`(`duvida`, `solucao`, `protocolo`, `cliente_fid`, `inicio`, `fim`, `periodo`) 
		VALUES ('$duvida','$solucao','$protocolo_id','$cliente_id','$inicio',NOW(),NOW())");
   
   }
   
#-------------------------------------------------------------------------------------------------------------------------------------------------  
   #função para gerar numero aletório para registro do cliente 
   # retorno ANO.NUM => 2018123456
	function randomNum(){
		$num = mt_rand (111111 , 999999);
		
		return date('Y').$num;
	}
	
	function verificaFormulario($conexao,$duvida,$solucao ,$protocolo,$cliente_id,$hora){
		
		if($duvida == NULL || $solucao == NULL){
			echo "<script>alert('Existe algum campo vazio!');location.href='formulario_cliente.php;</script>";


		}else{
			
			protocolo($conexao,$duvida,$solucao ,$protocolo,$cliente_id,$hora);
			echo "<script>alert('cadastrado  com sucesso!')</script>
				<script>window.location = 'formulario_cliente.php';</script>";
		}
		
	}
	
	function verificaLogin($conexao,$login){
		$banco =  mysqli_query($conexao, "SELECT `login` FROM `usuario` WHERE login = '$login'");
		$flag = [];
		$flag = mysqli_fetch_array($banco);
		
		if($flag[0]!= NULL){
			return True;	
		}else{
			return False;
		}
	}
	
	
?>