<!DOCTYPE html>
<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');


//Trata o cod da funcao
//Caso 01: busca as institui��es com convenio ativo
if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
    $codConsulta = $_GET["codConsulta"];
    $resultado = array();
    switch($codConsulta){
        case 1:                
            include __ROOT__.'/forms/cadastrarDemanda.php';   
            //echo constroi_tabela($resultado);
            break;
        case 2:           
        	include __ROOT__.'/forms/pesquisarDemanda.php';
        	//echo constroi_tabela($resultado);
        	break;       
     
    }
}

?>
