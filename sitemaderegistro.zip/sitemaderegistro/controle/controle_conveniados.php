<!DOCTYPE html>
<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/bd/bd_conveniados.php');
require_once(__ROOT__.'/util/utils.php');


//Trata o cod da funcao
//Caso 01: busca as institui��es com convenio ativo
if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
    $codConsulta = $_GET["codConsulta"];
    $resultado = array();
    switch($codConsulta){
        case 1:                
            $resultado = pequisaConveniados();
            echo constroi_tabela($resultado);
            break;
        case 2:            
            $resultado = pesquisaRegras();   
            echo constroi_tabela($resultado);
            break;
        case 3:  
           include __ROOT__.'/forms/pesquisaUsuarioPorInstituicao.php';         
            break;    
        case 4:  
           include __ROOT__.'/forms/pesquisaRegraPorInstituicao.php';            
            break;
        case 5:  
           include __ROOT__.'/forms/pesquisaImgConvenio.php';            
            break;
    }
}

?>
<html>
    <title>Sistema de Gest�o Integrado</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/index.css" />

    <body class="w3-light-grey">
        <!-- Top container -->        
        <br>        
        
            
            <!-- Footer -->
            <footer class="w3-container w3-padding-16 w3-light-grey">
                <h4>FOOTER</h4>
                <p>Powered by <a href="http://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
            </footer>

            <!-- End page content -->
        </div>

        <script>
        // Get the Sidenav
            var mySidenav = document.getElementById("mySidenav");

        // Get the DIV with overlay effect
            var overlayBg = document.getElementById("myOverlay");

        // Toggle between showing and hiding the sidenav, and add overlay effect
            function w3_open() {
                if (mySidenav.style.display === 'block') {
                    mySidenav.style.display = 'none';
                    overlayBg.style.display = "none";
                } else {
                    mySidenav.style.display = 'block';
                    overlayBg.style.display = "block";
                }
            }

        // Close the sidenav with the close button
            function w3_close() {
                mySidenav.style.display = "none";
                overlayBg.style.display = "none";
            }
        </script>

    </body>
</html>
