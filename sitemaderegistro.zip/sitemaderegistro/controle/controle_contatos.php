<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once(__ROOT__.'/util/utils.php');

session_start();

//Trata o cod da funcao
if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
    $codConsulta = $_GET["codConsulta"];
    $resultado = array();
    switch($codConsulta){
        case 1:                
            include __ROOT__.'/forms/cadastrarContato.php';   
            //echo constroi_tabela($resultado);
            break;
        case 2:           
        	include __ROOT__.'/forms/pesquisarContato.php';
        	//echo constroi_tabela($resultado);
        	break;       
     
    }
}

if (isset($_GET['cadastrar'])) {	
	if (salvarContato($_POST)) {
		salvarAlertaSessao('sucesso', 'Contato salvo com sucesso.', 'cadastrarContato');
	}
	else {
		salvarAlertaSessao('erro', 'N�o foi poss�vel salvar o contato. Por favor, contate o administrador do sistema.', 'cadastrarContato');
	}
	header('Location: /sgi/menu_contatos.php');
}

?>
