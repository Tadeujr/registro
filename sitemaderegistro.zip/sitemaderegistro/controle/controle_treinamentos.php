<?php
define('__ROOT__', dirname(dirname(__FILE__)));
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once(__ROOT__.'/util/utils.php');

session_start();

//Trata o cod da funcao
if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
	$codConsulta = $_GET["codConsulta"];
	$resultado = array();
	switch($codConsulta){
		case 1:		
			include __ROOT__.'/forms/agendarNovoTreinamento.php';
			break;
		case 2:
        	include __ROOT__.'/forms/listarTreinamentos.php';
			break;
	}
}

if (isset($_GET['agendar'])) {
	if (agendarTreinamento($_POST)) {
		echo '?';
		salvarAlertaSessao('sucesso', 'Treinamento agendado com sucesso.', 'agendarTreinamento');
	}
	else {
		salvarAlertaSessao('erro', 'N�o foi poss�vel agendar o treinamento. Por favor, contate o administrador do sistema.', 'agendarTreinamento');
	}
	header('Location: /sgi/menu_agendamentos.php');
}