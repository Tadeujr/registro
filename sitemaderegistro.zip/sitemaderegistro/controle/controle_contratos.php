<!DOCTYPE html>
<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');


//Trata o cod da funcao
if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
    $codConsulta = $_GET["codConsulta"];
    $resultado = array();
    switch($codConsulta){
        case 1:                
            include __ROOT__.'/forms/listarContratos.php';
            break; 
        case 2:
        	include __ROOT__.'/forms/cadastrarPagamento.php';
        	break;
        case 3:
        	include __ROOT__.'/forms/listarPagamento.php';
        	break;
     
    }
}

?>
