<?php
	include 'funcoes.php';
	
	$nome = $_POST['nome'];
	$login = $_POST['login'];
	$senha = $_POST['senha'];
	
	if(verificaLogin(conexao(),$login)){
		echo "<script>alert('Login já existente');location.href='formulario_usuario.php';</script>";
	}else{
		
	}
?>