<?php
//ini_set('display_errors', 1);
//error_reporting(E_ALL);

define('__ROOT__', dirname(dirname(__FILE__)));
require_once __ROOT__.'/model/sisgerpro/Fluxo.php';
require_once __ROOT__.'/model/sisgerpro/FluxoProcessoPapel.php';
require_once __ROOT__.'/model/sisgerpro/FluxoDigitalizacaoEntrada.php';
require_once __ROOT__.'/model/sisgerpro/GrafoAndamentos.php';
require_once __ROOT__.'/model/sisgerpro/Andamento.php';
require_once __ROOT__.'/model/sisgerpro/Intervalo.php';
require_once __ROOT__.'/model/sisgerpro/DateIntervalFunctions.php';

function conectarSisgerpro() {
	global $connSisgerpro;
	if (!$connSisgerpro) {		
		$connSisgerpro = new PDO("mysql:host=10.185.0.28;dbname=sisgerpro", "cesart", "cesart");
		$connSisgerpro->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	return $connSisgerpro;
}

function listarFluxos() {
	global $fluxos;
	
	if (!$fluxos) {
		$conn = conectarSisgerpro();
		
		$stmt = $conn->query("SELECT f.id, f.nome, f.dataInicio, f.dataFim FROM fluxo f");
		$stmt->execute();
		
		$fluxos = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$id = $row['id'];
			
			if ($id == 1) {
				$fluxo = new FluxoProcessoPapel();
			}
			else if ($id == 2) {
				$fluxo = new FluxoDigitalizacaoEntrada();
			}
			else {
				// gerar log, gerar excecao?
			}
			
			$fluxo->setId($row['id']);
			$fluxo->setNome($row['nome']);
			$fluxo->setDataInicio(new DateTime($row['dataInicio']));
			$fluxo->setDataFim(new DateTime($row['dataFim']));
					
			$fluxo->setAndamentos(getGrafoAndamentosByFluxo($id));
			$fluxo->setIntervalos(listarIntervalosByFluxo($id));
			
			$fluxos[$id] = $fluxo;
		}
	}
	
	return $fluxos;	
}

function listarStatus() {

}

function getGrafoAndamentosByFluxo($idFluxo) {
	$conn = conectarSisgerpro();
	
	$colunas = array(
		'sa.idAndamentoOrigem AS a_id',
		'sa.idAndamentoDestino AS b_id',
	);
	
	$query = "SELECT sa.idAndamentoOrigem AS a_id, sa.idAndamentoDestino AS b_id FROM sequencia_andamento sa WHERE sa.idFluxo = :idFluxo";	
	$stmt = $conn->prepare($query);
	$stmt->execute(array(':idFluxo' => $idFluxo));
	
	$grafo = new GrafoAndamentos();
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$a = getAndamentoById($row['a_id']);
		$b = getAndamentoById($row['b_id']);

		if (null === $a) {
			$a = new Andamento();
			$a->setId(0);
		}
		if (null === $b) {
			$b = new Andamento();
			$b->setId(0);
		}
		
		$grafo->addConexao($a, $b);
	}
	
	//echo 'Fluxo '.$idFluxo.'<br>';
	//$grafo->imprimir();
	
	return $grafo;
}

function listarIntervalosByFluxo($idFluxo) {
	$conn = conectarSisgerpro();
	
	$query = "SELECT i.id, i.idAndamentoOrigem, i.idAndamentoDestino, i.descricao, i.ordem, i.prioridade FROM intervalo i WHERE idFluxo = :idFluxo ORDER BY i.ordem ASC, i.prioridade DESC";
	$stmt = $conn->prepare($query);
	$stmt->execute(array(':idFluxo' => $idFluxo));
	
	$intervalos = array();
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		if (!isset($intervalos[$row['ordem']])) {
			$intervalo = new Intervalo();
			$intervalo->setDescricao($row['descricao']);
		}
		else {
			$intervalo = $intervalos[$row['ordem']];
		}
		
		$intervalo->addCaminho($row['id'], getAndamentoById($row['idAndamentoOrigem']), getAndamentoById($row['idAndamentoDestino']), $row['prioridade']);
		
		$intervalos[$row['ordem']] = $intervalo;
	}
	
	//print_r($intervalos);
	
	return $intervalos;
}

function getIntervaloById($idIntervalo) {
	$conn = conectarSisgerpro();
	
	$query = "SELECT i.id, i.idAndamentoOrigem, i.idAndamentoDestino, i.descricao, i.ordem, i.prioridade FROM intervalo i WHERE id = :id ORDER BY i.ordem ASC, i.prioridade DESC";
	$stmt = $conn->prepare($query);
	$stmt->execute(array(':id' => $idIntervalo));
	
	$intervalo = null;
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		if (!$intervalo) {
			$intervalo = new Intervalo();
			$intervalo->setDescricao($row['descricao']);	
		}		
		$intervalo->addCaminho($row['id'], getAndamentoById($row['idAndamentoOrigem']), getAndamentoById($row['idAndamentoDestino']), $row['prioridade']);
	}
	
	return $intervalo;
}

function getAndamentoById($idAndamento) {
	$conn = conectarSisgerpro();
	
	$query = "SELECT a.id, a.origem, a.destino, a.codDespacho FROM andamento a WHERE a.id = :idAndamento";
	$stmt = $conn->prepare($query);
	$stmt->execute(array(':idAndamento' => $idAndamento));
	
	$andamento = null;
	if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$andamento = new Andamento();
		$andamento->setId($row['id']);
		$andamento->setOrigem($row['origem']);
		$andamento->setDestino($row['destino']);
		$andamento->setCodDespacho($row['codDespacho']);
	}
	
	return $andamento;
}

function getFluxoById($idFluxo) {
	global $fluxos;
	
	if ($fluxos) {
		return $fluxos[$idFluxo];
	}
	
	$conn = conectarSisgerpro();
	
	$stmt = $conn->prepare("SELECT f.id, f.nome, f.dataInicio, f.dataFim FROM fluxo f WHERE f.id = :idFluxo");
	$stmt->bindValue('idFluxo', $idFluxo);
	$stmt->execute();
	
	$fluxo = null;
	if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$id = $row['id'];
		
		if ($id == 1) {
			$fluxo = new FluxoProcessoPapel();
		}
		else if ($id == 2) {
			$fluxo = new FluxoDigitalizacaoEntrada();
		}
		else {
			// gerar log, gerar excecao?
		}
		
		$fluxo->setId($row['id']);
		$fluxo->setNome($row['nome']);
		$fluxo->setDataInicio(new DateTime($row['dataInicio']));
		$fluxo->setDataFim(new DateTime($row['dataFim']));
				
		$fluxo->setAndamentos(getGrafoAndamentosByFluxo($id));
		$fluxo->setIntervalos(listarIntervalosByFluxo($id));
	}
		
	return $fluxo;
}

function setIdAndamento(&$andamento) {
	global $sisgerpro_andamentos;
	if (! $sisgerpro_andamentos) {
		$conn = conectarSisgerpro();
		
		$query = "SELECT a.id, a.origem, a.destino, a.codDespacho FROM andamento a ORDER BY a.id";
		$stmt = $conn->prepare($query);
		$stmt->execute();
		
		$sisgerpro_andamentos = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$a = new Andamento();
			$a->setId($row['id']);
			$a->setOrigem($row['origem']);
			$a->setDestino($row['destino']);
			$a->setCodDespacho($row['codDespacho']);
			
			$sisgerpro_andamentos[$a->__toString()] = $a;
		}
		//print_r($sisgerpro_andamentos);
	}
	
	$a = $sisgerpro_andamentos[$andamento->__toString()];
	if ($a !== null) {
		$andamento->setId($a->getId());
	}
}

function salvarTempos($protocolo) {	
	$conn = conectarSisgerpro();
	
	if ($protocolo->getId() === null) {
		$query = "INSERT INTO protocolo (numero, numRetorno, status, idFluxo) VALUES (:numero, :numRetorno, :status, :idFluxo)";
		$stmt1 = $conn->prepare($query);
	}
	else {
		$query = "UPDATE protocolo SET numero = :numero, numRetorno = :numRetorno, status = :status, idFluxo = :idFluxo WHERE id = :idProtocolo";
		$stmt1 = $conn->prepare($query);
		$stmt1->bindValue(':idProtocolo', $protocolo->getId(), PDO::PARAM_INT);
	}
		
	$idFluxo = $protocolo->getFluxo() ? $protocolo->getFluxo()->getId() : null;
	
	$stmt1->bindValue(':numero', $protocolo->getNumero(), PDO::PARAM_STR);
	$stmt1->bindValue(':numRetorno', $protocolo->getNumRetorno(), PDO::PARAM_INT);
	$stmt1->bindValue(':status', $protocolo->getStatus(), PDO::PARAM_STR);
	$stmt1->bindValue(':idFluxo', $idFluxo, PDO::PARAM_INT);
	$stmt1->execute();
	
	if ($protocolo->getId() === null) {
		$idProtocolo = $conn->lastInsertId();
		$protocolo->setId($idProtocolo);
	}
	else {
		$idProtocolo = $protocolo->getId();
	}
	
	$intervalos = $protocolo->getTempos();
	if ($intervalos !== null) {
		foreach ($intervalos as $intervalo) {
			$id = $intervalo->getId();
			$idIntervalo = $intervalo->getIdCaminho();
			$tempo = $intervalo->getTempo();
			
			if ($id === null) {
				$query = "INSERT INTO tempo (idProtocolo, idIntervalo, dtOrigem, dtDestino, tempoSegundos) VALUES (:idProtocolo, :idIntervalo, :dtOrigem, :dtDestino, :tempoSegundos)";
				$stmt2 = $conn->prepare($query);
			}
			else {
				$query = "UPDATE tempo SET dtOrigem = :dtOrigem, dtDestino = :dtDestino, tempoSegundos = :tempoSegundos WHERE idProtocolo = :idProtocolo AND idIntervalo = :idIntervalo";
				$stmt2 = $conn->prepare($query);
			}
			
			if ($tempo !== null) {
				$dtOrigem = $intervalo->getDtOrigem();
				$dtDestino = $intervalo->getDtDestino();
				$tempoSegundos = DateIntervalFunctions::intervalToSeconds($tempo);
				
				$stmt2->bindValue(':idProtocolo', $idProtocolo, PDO::PARAM_INT);
				$stmt2->bindValue(':idIntervalo', $idIntervalo, PDO::PARAM_INT);
				$stmt2->bindValue(':dtOrigem', $dtOrigem->format('Y-m-d H:i:s'), PDO::PARAM_STR);
				$stmt2->bindValue(':dtDestino', $dtDestino->format('Y-m-d H:i:s'), PDO::PARAM_STR);
				$stmt2->bindValue(':tempoSegundos', $tempoSegundos, PDO::PARAM_INT);
				$stmt2->execute();
			}
		}
	}
	
}

function buscarProtocolo($protocolo) {
	$conn = conectarSisgerpro();
	
	$query = "SELECT p.id, p.status, p.idFluxo FROM protocolo p WHERE p.numero = :numero AND p.numRetorno = :numRetorno";
	$stmt = $conn->prepare($query);
	$stmt->execute(array(':numero' => $protocolo->getNumero(), ':numRetorno' => $protocolo->getNumRetorno()));
	
	if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$protocolo->setId($row['id']);
		$protocolo->setStatus($row['status']);
		$protocolo->setFluxo(getFluxoById($row['idFluxo']));
		
		$intervalos = $protocolo->getFluxo() ? $protocolo->getFluxo()->getIntervalos() : null;
		
		if ($intervalos) {
			foreach ($intervalos as $intervalo) {
				$protIntervalo = new ProtocoloIntervalo();
				$protIntervalo->setProtocolo($protocolo->getNumero());
				$protIntervalo->setIntervalo($intervalo);
				
				$query2 = "SELECT t.id, t.idIntervalo, t.dtOrigem, t.dtDestino, t.tempoSegundos FROM tempo t INNER JOIN intervalo i ON t.idIntervalo = i.id WHERE t.idProtocolo = :idProtocolo AND i.descricao = :descricao";
				$stmt2 = $conn->prepare($query2);
				$stmt2->execute(array(':idProtocolo' => $protocolo->getId(), ':descricao' => $intervalo->getDescricao()));
				
				if ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
					$protIntervalo->setId($row2['id']);
					$protIntervalo->setIdCaminho($row2['idIntervalo']);
					$protIntervalo->setTempo(DateIntervalFunctions::secondsToInterval($row2['tempoSegundos']));
					$protIntervalo->setDtOrigem(new DateTime($row2['dtOrigem']));
					$protIntervalo->setDtDestino(new DateTime($row2['dtDestino']));
				}
				
				$protocolo->addTempo($protIntervalo);
			}
		}
		else $protocolo->setTempos(null);		
	}

}
