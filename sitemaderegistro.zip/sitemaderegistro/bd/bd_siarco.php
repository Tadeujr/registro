<?php
//ini_set('display_errors', 1);
//error_reporting(E_ALL);

define('__ROOT__', dirname(dirname(__FILE__)));
require_once __ROOT__.'/bd/bd_sisgerpro.php';
require_once __ROOT__.'/model/sisgerpro/Protocolo.php';


function conectarSiarco() {
	global $connSiarco;
	if (!$connSiarco) {
		$tns = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.185.0.4) (PORT = 1521))(CONNECT_DATA = (SID = prod)))";		
		$connSiarco = oci_connect("mercante", "mercante", $tns);
	}
	return $connSiarco;
}

function buscarAndamentosSisgerpro(DateTime $dataIni, DateTime $dataFim) {
	$connSiarco = conectarSiarco();
	
	$query = "
	SELECT
		a.nr_protocolo,
		a.sq_andamento,
		a.si_secao_origem,
		a.si_secao_destino,
		TO_CHAR(a.dt_andamento, 'YYYY-MM-DD HH24:MI:SS') AS dt_andamento,
		a.co_despacho 
	FROM dba_dnrc.andamento a
		LEFT OUTER JOIN dba_dnrc.processo p ON (a.nr_protocolo = p.nr_protocolo)
		LEFT OUTER JOIN dba_dnrc.solicitacao s ON (a.nr_protocolo = s.nr_protocolo)
	WHERE
		NOT EXISTS (
			SELECT 1 FROM solicitacao_evento se
			WHERE a.nr_protocolo = se.nr_protocolo
			AND se.co_evento = '046'
		)
		AND p.co_natureza_juridica IN ('206-2','213-5','230-5') 
		AND s.co_ato IN ('002','003','080','090','091','307','309','315','316','317','318')
		AND a.nr_protocolo IN (
			SELECT b.nr_protocolo
			FROM andamento b
			WHERE b.dt_andamento BETWEEN to_date(:dataIni, 'yyyy-mm-dd hh24:mi:ss') AND to_date(:dataFim, 'yyyy-mm-dd hh24:mi:ss')
			AND b.sq_andamento = 1			
		)
		AND s.sq_solicitacao = 1
	ORDER BY a.nr_protocolo ASC, a.sq_andamento ASC";
	
	//echo $dataIni->format('Y-m-d H:i:s')."<br>\n";
	//echo $dataFim->format('Y-m-d H:i:s')."<br>\n";
	
	//echo $query."<br>\n";
	//die();
	
	$stmt = oci_parse($connSiarco, $query);
		
	oci_bind_by_name($stmt, ':dataIni', $dataIni->format('Y-m-d H:i:s'));
	oci_bind_by_name($stmt, ':dataFim', $dataFim->format('Y-m-d H:i:s'));
	
	oci_execute($stmt);
	
	$result = array();
	
	$i = -1;
	$protocoloAnterior = null;
	$secaoOrigemAnterior = null;
	while (($row = oci_fetch_array($stmt, OCI_ASSOC + OCI_RETURN_NULLS)) != null) {
		$nrProtocolo = $row['NR_PROTOCOLO'];
		$sqAndamento = $row['SQ_ANDAMENTO'];
		$secaoOrigem = $row['SI_SECAO_ORIGEM'];
		$secaoDestino = $row['SI_SECAO_DESTINO'];
		$dtAndamento = $row['DT_ANDAMENTO'];
		$codDespacho = $row['CO_DESPACHO'];
				
		if ($nrProtocolo !== $protocoloAnterior) {
			$i++;
			$protocoloAnterior = $nrProtocolo;
			$numRetorno = 0;
			$result[$i] = new Protocolo($nrProtocolo, $numRetorno);
		}
		else {
			if ($secaoOrigem === "PR" && $secaoOrigemAnterior !== "PR") {
				$i++;
				$numRetorno++;
				$result[$i] = new Protocolo($nrProtocolo, $numRetorno);	
			}
		}

		$andamento = new Andamento();
		$andamento->setSq($sqAndamento);
		$andamento->setOrigem($secaoOrigem);
		$andamento->setDestino($secaoDestino);
		$andamento->setCodDespacho($codDespacho);
		//$andamento->setId(-1);
		setIdAndamento($andamento);
		$andamento->setData(new DateTime($dtAndamento));
		
		$result[$i]->addAndamento($andamento);
		
		$secaoOrigemAnterior = $secaoOrigem;
	}
	
	oci_free_statement($stmt);
	oci_close($connSiarco);
	
	return $result;
}
