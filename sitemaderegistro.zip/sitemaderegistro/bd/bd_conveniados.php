<?php
error_reporting(6135);
 
global $resultado;

if (isset($_GET["codConsulta"]) and ! empty($_GET["codConsulta"])) {
    $codConsulta = $_GET["codConsulta"];
    if ($codConsulta == 1) {
        pequisaConveniados();
    }
    else if ($codConsulta == 2) {
        pesquisaRegras();
    }    
}

function pequisaConveniados() {
    $db = $db = "(DESCRIPTION =
                (ADDRESS =
                (PROTOCOL = TCP)
                (HOST = 10.185.2.20)
                (PORT = 1521)
                
             )
           (CONNECT_DATA = (SID = xe))
         )";

    try {
        $user = "es_portal";
        $passwd = "portal";
        $db_conn = ocilogon($user, $passwd, $db);

        $sql = "select distinct a.tin_nom_inst as Instituicao, decode(b.wis_dat_ativacao,null,'Nao Conveniado',b.wis_dat_ativacao) as data_ativacao
        from tab_instituicao a join wbs_inst_serv b on a.tin_cnpj = b.wis_tin_cnpj 
        where (a.tin_nom_inst not like '%TESTE%' and a.tin_nom_inst not like '%HOMO%' and a.tin_nom_inst not like '%JUNTA%') order by 1";

        if (!$db_conn)
            throw new Exception('Erro de Conex�o');
        $query = OCIParse($db_conn, $sql);

        OCIExecute($query);      

        while (OCIFetchInto($query, $usuario, OCI_ASSOC)) {
            $resultado[] = $usuario;
        }
        OCILogoff($db_conn);
    } catch (Exception $e) {
        OCILogoff($db_conn);
    }
    return $resultado;
}


function pesquisaRegras() {
    $db = $db = "(DESCRIPTION =
                (ADDRESS =
                (PROTOCOL = TCP)
                (HOST = 10.185.2.20)
                (PORT = 1521)
                
             )
           (CONNECT_DATA = (SID = xe))
         )";

    try {
        $user = "es_portal";
        $passwd = "portal";
        $db_conn = ocilogon($user, $passwd, $db);

        $sql = "select Prefeitura,  Secretaria
from(
select distinct ti.tin_cnpj as CNPJ, ti.tin_nom_inst as Prefeitura, tti.tti_desc as Secretaria from tab_req_inst_act a
join tab_instituicao ti on ti.tin_cnpj = a.tri_tin_cnpj
join tab_inf_adicional tp on tp.tia_cod_seq = a.tri_tia_cod_seq
join tab_tipo_informacao tti on tti.tti_tip_inform = tp.tia_tti_tip_inform
where tp.tia_tti_tip_inform in ('34' , '35')
union
select distinct ti.tin_cnpj, ti.tin_nom_inst, tig.tti_desc from tab_req_inst_act_group a
join tab_instituicao ti on ti.tin_cnpj = a.trg_tin_cnpj
join tab_tipo_informacao_grupo tig on tig.tti_tip_inform = a.trg_tgi_cod_grupo
and tig.tti_tip_inform in (select ab.tti_tip_inform from tab_tipo_informacao_grupo ab where ab.tti_desc like '%VISA%')
union
select distinct ti.tin_cnpj as CNPJ, ti.tin_nom_inst as Prefeitura, tti.tti_desc from tab_req_inst_act a
join tab_instituicao ti on ti.tin_cnpj = a.tri_tin_cnpj
join tab_inf_adicional tp on tp.tia_cod_seq = a.tri_tia_cod_seq
join tab_tipo_informacao tti on tti.tti_tip_inform = tp.tia_tti_tip_inform
where tp.tia_tti_tip_inform ='25' 
union
select distinct ti.tin_cnpj, ti.tin_nom_inst, tig.tti_desc from tab_req_inst_act_group a
join tab_instituicao ti on ti.tin_cnpj = a.trg_tin_cnpj
join tab_tipo_informacao_grupo tig on tig.tti_tip_inform = a.trg_tgi_cod_grupo
and tig.tti_tip_inform in (select ab.tti_tip_inform from tab_tipo_informacao_grupo ab where ab.tti_desc like '%MEIO AMBIENTE%')
) where (Prefeitura not like '%TESTE%' AND Prefeitura not like '%HOMOLOGACAO%')
order by 1";

        if (!$db_conn)
            throw new Exception('Erro de Conex�o');
        $query = OCIParse($db_conn, $sql);

        OCIExecute($query);

        global $resultado;

        while (OCIFetchInto($query, $usuario, OCI_ASSOC)) {
            $resultado[] = $usuario;
        }
        OCILogoff($db_conn);
    } catch (Exception $e) {
        OCILogoff($db_conn);
    }
    return $resultado;
}

function pesquisaUsuariosAtivos($instituicao) {
    $db = $db = "(DESCRIPTION =
                (ADDRESS =
                (PROTOCOL = TCP)
                (HOST = 10.185.2.20)
                (PORT = 1521)
                
             )
           (CONNECT_DATA = (SID = xe))
         )";

    try {
        $user = "es_portal";
        $passwd = "portal";
        $db_conn = ocilogon($user, $passwd, $db);

        $sql = "select a.tir_nom_resp as nome, ' ' || a.tir_email as email, decode(a.tir_status,'1','Ativo', 'Inativo') as Situacao, '' || a.tir_ddd_tel  || ' ' || a.tir_telefone as tel, c.tir_nom_regional as Instituicao from tab_inst_responsavel a
join tab_inst_regional c on (a.tir_tin_cnpj = c.tir_tin_cnpj)
where a.tir_status = '1' and c.tir_nom_regional like  UPPER('%".$instituicao."%') order by 1 asc
"; 
        
        
        if (!$db_conn)
            throw new Exception('Erro de Conex�o');
        $query = OCIParse($db_conn, $sql);

        OCIExecute($query);

        global $resultado;

        while (OCIFetchInto($query, $usuario, OCI_ASSOC)) {
            $resultado[] = $usuario;
        }
        OCILogoff($db_conn);
    } catch (Exception $e) {
        OCILogoff($db_conn);
    }
    return $resultado;
}

//Pesquisa os nomes das instituicoes
function pesquisaNomesInstituicao() {
    $db = $db = "(DESCRIPTION =
                (ADDRESS =
                (PROTOCOL = TCP)
                (HOST = 10.185.2.20)
                (PORT = 1521)
                
             )
           (CONNECT_DATA = (SID = xe))
         )";

    try {
        $user = "es_portal";
        $passwd = "portal";
        $db_conn = ocilogon($user, $passwd, $db);

        $sql = "select distinct c.tir_tin_cnpj as CNPJ, c.tir_nom_regional as Instituicao 
        from tab_inst_regional c order by c.tir_nom_regional asc"; 
        
        
        if (!$db_conn)
            throw new Exception('Erro de Conex�o');
        $query = OCIParse($db_conn, $sql);

        OCIExecute($query);

        global $resultado;

        while (OCIFetchInto($query, $usuario, OCI_ASSOC)) {
            $resultado[] = $usuario;
        }
        OCILogoff($db_conn);
    } catch (Exception $e) {
        OCILogoff($db_conn);
    }
    return $resultado;
}


//Pesquisa as repras por Instituicao
function pesquisaRegrasPorInst($cnpj, $regra) {
    $resultado = array();
    $db = $db = "(DESCRIPTION =
                (ADDRESS =
                (PROTOCOL = TCP)
                (HOST = 10.185.2.20)
                (PORT = 1521)
                
             )
           (CONNECT_DATA = (SID = xe))
         )";

    try {
        $user = "es_portal";
        $passwd = "portal";
        $db_conn = ocilogon($user, $passwd, $db);

        $sql = "select tp.tia_desc as Documentos from tab_req_inst_act a
join tab_instituicao ti on ti.tin_cnpj = a.tri_tin_cnpj
join tab_inf_adicional tp on tp.tia_cod_seq = a.tri_tia_cod_seq
join tab_tipo_informacao tti on tti.tti_tip_inform = tp.tia_tti_tip_inform
where tti.tti_desc like UPPER('%".$regra."%') and ti.tin_cnpj = "."'$cnpj"."'
union
select distinct txb.tia_desc as Documentos from tab_req_inst_act_group a
join tab_instituicao ti on ti.tin_cnpj = a.trg_tin_cnpj
join tab_tipo_informacao_grupo tig on tig.tti_tip_inform = a.trg_tgi_cod_grupo
join tab_grupo_inf_adicional txa on txa.tgi_cod_grupo = tig.tti_tip_inform
join tab_inf_adicional txb on txb.tia_cod_seq = txa.tgi_tia_cod_seq
and tig.tti_tip_inform in (select ab.tti_tip_inform from tab_tipo_informacao_grupo ab where ab.tti_desc like UPPER('%".$regra."%'))
and ti.tin_cnpj = '".$cnpj."' order by 1 asc"; 
        
        
        
        if (!$db_conn)
            throw new Exception('Erro de Conex�o');
        $query = OCIParse($db_conn, $sql);

        OCIExecute($query);        

        while (OCIFetchInto($query, $usuario, OCI_ASSOC)) {
            $resultado[] = $usuario;
        }
        OCILogoff($db_conn);
    } catch (Exception $e) {
        OCILogoff($db_conn);
    }
    return $resultado;
}

?>