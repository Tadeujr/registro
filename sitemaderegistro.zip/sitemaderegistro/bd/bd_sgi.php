<?php

$funcao = $_GET['funcao']; 

if($funcao == "responderOficio"){
	$id = $_GET['id'];
	$usuario =  $_GET['usuario'];
	$data_resposta =  $_GET['dataResposta'];
    $resultado = responderOficio($usuario, $data_resposta, $id);
	echo $resultado;
}

function conectarSgi() {
	global $conn;
	if (!$conn) {
		$conn = new PDO("mysql:host=10.185.0.28;dbname=sgi", "cesart", "cesart");
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	return $conn;
}

function salvarContato($contato) {
	$nome = $contato['nome'];
	$nomeInstituicao = $contato['nomeInstituicao'];
	$tipoInstituicao = $contato['tipoInstituicao'];
	$email = $contato['email'];
	$telefoneComercial = $contato['telefoneComercial'];
	$telefoneParticular = $contato['telefoneParticular'];
	
	// TODO validacao dos dados do contato
	
	$conn = conectarSgi();
	
	$stmt = $conn->prepare("INSERT INTO contato (nome, tipoInstituicao, nomeInstituicao, email, telefoneComercial, telefoneParticular) VALUES (?, ?, ?, ?, ?, ?)");
	$stmt->bindValue(1, $nome);
	$stmt->bindValue(2, $tipoInstituicao);
	$stmt->bindValue(3, $nomeInstituicao);
	$stmt->bindValue(4, $email);
	$stmt->bindValue(5, $telefoneComercial);
	$stmt->bindValue(6, $telefoneParticular);
	
	$stmt->execute();
	
	return true;
}

function agendarTreinamento($treinamento) {
	$data = $treinamento['data'];
	$horario = $treinamento['horario'];
	$instituicao = $treinamento['instituicao'];
	$funcionarios = explode("-", $treinamento['funcionarios']);
	$local = $treinamento['local'];
	$contatos = explode("-", $treinamento['contatos']);
	$observacoes = $treinamento['observacoes'];
	
	$dataHora = DateTime::createFromFormat('d/m/Y H:i', $data. " " .$horario);
	
	// TODO validacao dos dados do treinamento
	
	$conn = conectarSgi();
	
	$conn->beginTransaction();
	
	$stmt = $conn->prepare("INSERT INTO treinamento (instituicao, local, observacao, dataHora) VALUES (?, ?, ?, ?)");
	$stmt->bindValue(1, $instituicao);
	$stmt->bindValue(2, $local);
	$stmt->bindValue(3, $observacoes);
	$stmt->bindValue(4, $dataHora->format('Y-m-d H:i:s'));
	
	$stmt->execute();
	
	$idTreinamento = $conn->lastInsertId();
	
	$stmt = $conn->prepare("INSERT INTO treinamentoFuncionario (idTreinamento, idFuncionario) VALUES (?, ?)");
	$stmt->bindValue(1, $idTreinamento);
	$stmt->bindParam(2, $idFuncionario);
	foreach ($funcionarios as $idFuncionario) {
		$stmt->execute();
	}
	
	$stmt = $conn->prepare("INSERT INTO treinamentoContato (idTreinamento, idContato) VALUES (?, ?)");
	$stmt->bindValue(1, $idTreinamento);
	$stmt->bindParam(2, $idContato);
	foreach ($contatos as $idContato) {
		$stmt->execute();
	}
	
	$conn->commit();
	
	return true;
}

function pesquisarContatos() {
	$conn = conectarSgi();
	
	$consulta = $conn->query("SELECT c.id AS Id, c.nome AS Nome, tic.nomeTipo AS Instituicao, c.nomeInstituicao as 'Nome Instituicao', c.email AS 'E\-mail', c.telefoneComercial AS 'Telefone Comercial', c.telefoneParticular AS 'Telefone Particular' FROM contato c INNER JOIN tipoInstituicaoContato tic ON c.tipoInstituicao = tic.id");
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return $result;
}

function pesquisarContatoPorId($id) {
	$conn = conectarSgi();
	
	$consulta = $conn->prepare("SELECT c.id AS Id, c.nome AS Nome, tic.nomeTipo AS Instituicao, c.nomeInstituicao as 'Nome Instituicao', c.email AS 'E\-mail', c.telefoneComercial AS 'Telefone Comercial', c.telefoneParticular AS 'Telefone Particular' FROM contato c INNER JOIN tipoInstituicaoContato tic ON c.tipoInstituicao = tic.id WHERE c.id = :idContato");
	$consulta->execute(array(':idContato' => $id));
	
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return empty($result) ? $result : $result[0];
}

function pesquisarFuncionarios() {
	$conn = conectarSgi();
	
	$consulta = $conn->query("SELECT id as Id, nome as Nome, login as Login FROM funcionario");
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return $result;	
}

function pesquisarFuncionarioPorId($id) {
	$conn = conectarSgi();
	
	$consulta = $conn->prepare("SELECT f.id AS Id, f.login AS Login, f.nome as Nome FROM funcionario f WHERE f.id = :idFuncionario");
	$consulta->execute(array(':idFuncionario' => $id));
	
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return empty($result) ? $result : $result[0];
}

function pesquisarTreinamentos() {
	$conn = conectarSgi();
	
	$consulta = $conn->query("SELECT id, instituicao, local, observacao, dataHora FROM treinamento");
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);

	foreach ($result as $i => $row) {
		$result[$i]['contatos'] = pesquisarContatosTreinamento($row['id']);
		$result[$i]['funcionarios'] = pesquisarFuncionariosTreinamento($row['id']);
	}
	
	return $result;
}

function pesquisarContatosTreinamento($idTreinamento) {
	$conn = conectarSgi();
	
	$consulta = $conn->prepare("SELECT idContato FROM treinamentoContato WHERE idTreinamento = :idTreinamento");
	$consulta->execute(array(':idTreinamento' => $idTreinamento));
		
	$contatosId = $consulta->fetchAll(PDO::FETCH_ASSOC);
	$contatos = array();
		
	foreach ($contatosId as $id) {
		$contatos[] = pesquisarContatoPorId($id['idContato']);
	}
	
	return $contatos;
}

function pesquisarFuncionariosTreinamento($idTreinamento) {
	$conn = conectarSgi();
	
	$consulta = $conn->prepare("SELECT idFuncionario FROM treinamentoFuncionario WHERE idTreinamento = :idTreinamento");
	$consulta->execute(array(':idTreinamento' => $idTreinamento));
		
	$funcionariosId = $consulta->fetchAll(PDO::FETCH_ASSOC);
	$funcionarios = array();
		
	foreach ($funcionariosId as $id) {
		$funcionarios[] = pesquisarFuncionarioPorId($id['idFuncionario']);
	}
	
	return $funcionarios;
}

function pesquisarTiposInstituicao() {
	$conn = conectarSgi();
	
	$consulta = $conn->query("SELECT id, nomeTipo FROM tipoInstituicaoContato");
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return $result;
}

//Metodo que permite salvar um Oficio recebido pela JUCEES
function salvarOficio($oficio){	
	
	//var_dump($oficio);
	
	$origem = $oficio['origem'];
	$numero = $oficio['numero'];	
	$dtRecebimento = DateTime::createFromFormat('d/m/Y', $oficio['dtRecebimento']);	
	$usuario_cadastro = $oficio['usuario_cadastro'];	
	$nomeArquivo = $oficio['nomeArquivo'];
		
	$conn = conectarSgi();
	
	$stmt = $conn->prepare("INSERT INTO oficio (origem,numero,data_recebimento,usuario_cadastro,nome_arquivo,data_limite_resposta,usuario_resposta,data_resposta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
	$stmt->bindValue(1, $origem);
	$stmt->bindValue(2, $numero);
	$stmt->bindValue(3, $dtRecebimento->format('Y-m-d'));
	$stmt->bindValue(4, $usuario_cadastro);
	$stmt->bindValue(5, $nomeArquivo);	
	
	//Valida se � um oficio com data limite de entrega, ou seja, necessita de resposta
	if( mb_strlen($oficio['dataEntrega'],'utf8') == 10 ){
		$dataLimite = DateTime::createFromFormat('d/m/Y', $oficio['dataEntrega']);
		$stmt->bindValue(6, $dataLimite->format('Y-m-d'));				
	}else{		
		$stmt->bindValue(6, null);
	}
	$stmt->bindValue(7, null);
	$stmt->bindValue(8, null);
	
	$stmt->execute();
	
	return true;
}


//listar os oficios que necessitam de resposta
function pesquisarOficiosResposta() {
	$conn = conectarSgi();

	$consulta = $conn->query("SELECT * FROM oficio WHERE data_limite_resposta is not null");
	$result = $consulta->fetchAll(PDO::FETCH_ASSOC);
	
	return $result;
}

//listar os oficios que necessitam de resposta
function responderOficio($usuario, $data_resposta, $id) {
	$d = str_replace('/', '-', $data_resposta);
	$data_nova = date('Y-m-d', strtotime($d));
		
	$resultado = ''; 
	
	$conn = conectarSgi();
	
	$stmt = $conn->prepare("UPDATE oficio set usuario_resposta=?, data_resposta=? where id=?");
	$stmt->bindValue(1, $usuario);
	$stmt->bindValue(2, $data_nova);
	$stmt->bindValue(3, $id);
			
	
	$stmt->execute();
	
		if(!$stmt->execute()){
		    echo "Erro!";
		} else {
		    echo "Respondido com Sucesso!";
		}
	
	return $resultado;
}