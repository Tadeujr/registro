<?php

$resultado = array();

//Funcao que lista todos os contratos da JUCEES
function listarContratos() {
	// Caso 01 - lista todos os contratos
	$db = mysql_connect ( '10.185.0.29', 'pscs', 'pscs' ) or die ( "Database error" );
	mysql_select_db ( 'bd_contratos', $db );
	$query = "select te.nome as 'NOME EMPRESA', t.objeto as OBJETO, date_format(t.dt_assinatura,'%d/%m/%Y') as 'DT. ASSINATURA', 
			date_format(t.dt_inicio_vigencia, '%d/%m/%Y')as 'DT. INIC. VIGENCIA', 
			date_format(t.dt_vencimento,'%d/%m/%Y') as 'DT. VENC.', 
			t.numero as NUMERO, 
			t.sep as SEP, t.gestor_titular as 'TITULAR', 
			t.gestor_substituto as 'SUBSTITUTO', t.fiscal_substituto as 'FISCAL SUB.' 
			from tbl_contrato t left join tbl_empresa te on t.id_empresa = te.id_empresa 
			order by dt_vencimento desc
			";
	$result = mysql_query ( $query );
	
	while ( $row = mysql_fetch_array ( $result, MYSQL_ASSOC ) ) {
		$resultado[] = $row;
	}

	mysql_close ( $db );
	return $resultado;
}

?>