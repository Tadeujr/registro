<?php

	include 'funcoes.php';
	session_start(); # Deve ser a primeira linha do arquivo

	
	$nome = $_POST['nome'];
	$duvida = $_POST['duvida'];
	$solucao = $_POST['solucao'];
	$protocolo = $_SESSION['protocolo'];
	$horas = $_SESSION['horas'];
	$teste = password_hash(123, PASSWORD_DEFAULT);
	
	if($nome != NULL){
		$pessoa_id =  addPessoa(conexao(),$nome);
		$cliente_id = addCliente(conexao(),$pessoa_id);
		verificaFormulario(conexao(),$duvida,$solucao ,$protocolo,$cliente_id,$horas);
	}else{
		echo "<script>alert('Informe o nome por favor!');location.href='formulario_cliente.php';</script>";
		
	}
	
	
?>
