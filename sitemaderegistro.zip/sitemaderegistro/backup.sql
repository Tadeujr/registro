<?php 
	
include 'conexao.php';
	
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função lista os clientes do sistema
	#retorna uma matriz com todos os clientes
	function listarClientes($conexao){
		$banco = mysqli_query($conexao, "select * from empregado");
		$saida = [];
		$clientes = [];
		$i = 0;
		
		while($clientes= mysqli_fetch_array($banco)){
			array_push($saida,$clientes);
			
			
		}
	
		return $saida;
   }
   
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função busca um determinado cliente  do sistema
	# o retorno e um vetor
	function buscarCliente($conexao,$busca){
		$banco = mysqli_query($conexao, "select * from empregado where nome ='$busca'"); # mudar para protocolo
		$saida = [];
		$cliente = [];
		
		$cliente= mysqli_fetch_array($banco);
	
		return $cliente;
   }
    
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função adicionar clientes
	#adiciona nova duvida ao banco
	function addCliente($conexao,$nome,$idade,$salario,$car){
		$banco = mysqli_query($conexao, "insert into empregado (nome,idade,salario,caracteristica) 
		values ('$nome','$idade','$salario','$car')"); # mudar para protocolo
		
	
		
   }
   
#-------------------------------------------------------------------------------------------------------------------------------------------------  
   #função para gerar numero aletório para registro do cliente 
   # retorno ANO.NUM => 2018123456
	function randomNum(){
		$num = mt_rand (111111 , 999999);
		
		return date('Y').$num;
	}
/*	
#------------------------------------------------------------------------------------------------------------------------------------------------
	#função confere protocolo
	function addCliente($conexao,$protocolo){
		$banco = mysqli_query($conexao, "select * from empregado where nome ='$busca'"); # mudar para protocolo
		$saida = [];
		$cliente = [];
		
		$cliente= mysqli_fetch_array($banco);
	
		return $cliente;
   }
	*/

#--------------------------------------------------------------------------------------------------------------------------------------------------
	#funçao para desconecatar do banco de dados
	function desconectar($conexao){
		mysql_close($conexao);
	}
	$conexao = conexao();
	
	
	$saida = [];
	$saida = listarClientes($conexao);
	addCliente($conexao,'Andreza',18,570.00,'Loira');
	
	echo $saida[2]['nome'];
	

	
?>