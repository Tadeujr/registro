<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/bd/bd_contratos.php');
require_once(__ROOT__.'/util/utils.php');




?>
