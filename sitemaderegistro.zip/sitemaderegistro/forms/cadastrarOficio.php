<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');
require_once(__ROOT__.'/bd/bd_sgi.php');


$oficio = array();

if (!empty($_POST)) {	
	
	if (($_FILES['upload']['name']!="")){
		// Where the file is going to be stored
		$caminho = date("Ymd").date("Hms");//caminho do arquivo a ser salvo no bd
		
		$target_dir = __ROOT__."/imgoficios/";
		$file = $_FILES['upload']['name'];
		$path = pathinfo($file);
		//$filename = $path['filename'];
		$filename = $caminho;
		$ext = $path['extension'];
		$temp_name = $_FILES['upload']['tmp_name'];
		$path_filename_ext = $target_dir.$filename.".".$ext;
		
		$oficio['origem'] = $_POST['origem'];
		$oficio['numero'] = $_POST['numero'];
		$oficio['usuario_cadastro'] = 'teste';
		$oficio['dtRecebimento'] = $_POST['dataRecebimento'];		
		$oficio['nomeArquivo'] = $filename.".".$ext;
		$oficio['dataEntrega'] = $_POST['dataEntrega'];
		
		
		
		// Check if file already exists
		if (file_exists($path_filename_ext)) {
			echo "Arquivo n�o existe";
		}else{
			move_uploaded_file($temp_name,$path_filename_ext);
			salvarOficio($oficio);
			echo "Salvo com Sucesso";
		}
	}
}







?>	
<br>
	<form class="w3-container" method="post" action="forms/cadastrarOficio.php" enctype="multipart/form-data">
		<h2>Cadastrar Novo Of�cio</h2>
			<div class="w3-row-padding">
									
					<div><br>Origem:
					<input id="origem" name="origem" class="w3-input w3-border w3-round-large" type="text" maxlength="150" data-validation="required" data-validation-error-msg="Campo obrigat�rio!">
					</div>					
					<div>
					Numero: <input id="numero" name="numero" class="w3-input w3-border w3-round" maxlength="20" data-validation="required" data-validation-error-msg="Campo obrigat�rio!"></input>
					</div>
					<div class="w3-half" style="padding-left: 64px; padding-right: 64px;">
						<label>Data Recebimento:</label> 
						<input name="dataRecebimento" id="dataRecebimento" class="w3-input w3-border w3-round gldp-el" gldp-id="calendarEntrada" autocomplete="off" readonly="" value="Clique aqui para selecionar a data" type="text" style="cursor: pointer"> 
						<br />
						<div id="calendarEntrada" gldp-el="calendarEntrada" style="width: 320px; height: 300px; position: initial; margin-bottom: 15px; margin-left: auto; margin-right: auto;"></div>
					</div>							
											
					<br>
					<div><input class="w3-check" id="aprovacao" type="checkbox" name="aprovacao" value="aprovado"> Necessita Resposta?</div>
					<br>
					<div id="div_data" class="w3-group" style="padding-left: 64px; padding-right: 64px; display:none;">
						<label>Prazo de Resposta:</label> 
						<input name="dataEntrega" id="dataEntrega" class="w3-input w3-border w3-round gldp-el" gldp-id="calendarSaida" autocomplete="off" readonly="" value="Clique aqui para selecionar a data" type="text" style="cursor: pointer"> 
						<br />
						<div id="calendarSaida" gldp-el="calendarSaida" style="width: 320px; height: 300px; position: initial; margin-bottom: 15px; margin-left: auto; margin-right: auto;"></div>
					</div>				
					<br>
					<div>
					<!-- Validate that file isn't larger than 3 mega bytes --> 
					<br><input type="file" id="upload" name="upload">
					</div>
					<div class="w3-third">&nbsp;</div>
					<div class="w3-third">
						<button id="submit" class="w3-btn-block w3-large w3-round w3-blue" value="Salvar" name="submit">Salvar</button>
					</div>
					<div class="w3-third">&nbsp;</div>
					
				</div>	
	</form>



<script src="js/glDatePicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/jquery.form-validator.min.js"></script>
<script>
	$('input#dataRecebimento').glDatePicker({
        dowNames: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        onClick: (function(el, cell, date, data) { el.val(((date.getDate() > 9) ? date.getDate() : '0' + date.getDate()) + '/' + (((date.getMonth()+1) > 9) ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1)) + '/' + date.getFullYear()); $('input#dataRecebimento').trigger('change'); })
    });

	$('input#dataEntrega').glDatePicker({
        dowNames: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        onClick: (function(el, cell, date, data) { el.val(((date.getDate() > 9) ? date.getDate() : '0' + date.getDate()) + '/' + (((date.getMonth()+1) > 9) ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1)) + '/' + date.getFullYear()); $('input#dataEntrega').trigger('change'); })
    });

	//Metodo para habilitar aprovador caso a demanda necessite de aprovacao
	$("#aprovacao").click(function () {		
	    if ($('#aprovacao').is(':checked')) {
	        //$("#aprovador").val($(".hidden1").val());
	        $("#div_data").show();
	    } else {
	        $("#div_data").val("");
	        $("#div_data").hide();
	    }
	});



	 $.validate();

	
        
</script>


