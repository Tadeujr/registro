<?php
define ( '__ROOT__', dirname(dirname( __FILE__ )));
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once (__ROOT__ . '/util/utils.php');


$resultado = pesquisarOficiosResposta();


if (empty($resultado)):
	exibirAlerta('aviso', 'N�o existem oficios a serem respondidos.'); 
else: ?>
<div class="w3-container">
	<br>

<?php foreach ($resultado as $oficio): ?>			
	<ul class="w3-ul w3-card-4 w3-white" style="border: 1px;>	

		<li class="w3-padding-16" value="<?=$oficio['id']?>" ">		    		
					
			<p><b>Institui��o: </b><?= $oficio['origem'] ?></p>
			<p><b>Numero: </b><?= $oficio['numero'] ?></p>	
			<p><b>Data Recebimento: </b><?= $oficio['data_recebimento'] ?></p>					
			<p><img src="img/calendar.png" class="w3-left w3-circle w3-margin-right" style="width:35px"><b style="color:red">Prazo: </b><?= $oficio['data_limite_resposta'] ?></p>
			<p><img src="img/oficio.png" class="w3-left w3-circle w3-margin-right" style="width:35px"><b><a target="_blank" href="<?= 'imgoficios/' .$oficio['nome_arquivo'] ?>">Visualizar Oficio </a></b></p>			
			Data da Resposta:<input class="dt" type="text" maxlength="10" name="dtEntrega<?=$oficio['id']?>" id="dtEntrega<?=$oficio['id']?>" onkeypress="mascara(this, '##/##/####')">
			<a href="#" id="teste"><img src="img/confirm.png" >
			<input name="idOficio" type="hidden" value="<?=$oficio['id']?>"/>Responder</a><br>		
		</li>
			</ul>
<?php endforeach; ?>

</div>
<?php endif; ?>
<br/><br/>


<script src="js/jquery.form-validator.min.js"></script>


<script>
$(document).ready(function(){ 
	//Metodo que registra novas demandas
	
    //Get the id of list items   
	$('a#teste').click(function() {
	var tid = $('input[name="idOficio"]', this).val();
	
    // var data = $("#dataEntrega").val();
	var data = $(".dt" ).val();

       $.get( "bd/bd_sgi.php?funcao=responderOficio&id="+tid+"&usuario=henrique&dataResposta="+data, function(resp) {
          	   alert(resp);          	 
    	 });      
   	});	
});
</script>

<script language="JavaScript">
 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
 </script>