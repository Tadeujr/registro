<!DOCTYPE html>
<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/bd/bd_conveniados.php');
require_once(__ROOT__.'/util/utils.php');

$nomesInstituicoes;
$nomesInstituicoes = pesquisaNomesInstituicao();

$resultado = '';
$pesquisado = false;

if (isset($_GET["cnpj"]) and ! empty($_GET["cnpj"]) and isset($_GET["regra"]) and ! empty($_GET["regra"])) {    
    $regra = strtoupper(utf8_decode($_GET["regra"]));  
    $cnpj = $_GET["cnpj"]; 
    
    $regrasInst = array();
    $regrasInst = pesquisaRegrasPorInst($cnpj, $regra);
    if (empty($regrasInst)) {
        $resultado = '';
    } else {
        $resultado = constroi_tabela($regrasInst);
    }
    $pesquisado = true;
}

?>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" type="text/css" href="css/style.css" />

<body>

        <br>     
    
        <div class="w3-container">
            <select id="cnpj" class="w3-select w3-border">
                <?php foreach ($nomesInstituicoes as $n) { ?>
                    <option value="<? echo $n['CNPJ']; ?>"><? echo $n['INSTITUICAO']; ?></option>
                <?php } ?>
            </select>
            <select id="regra">
                <option value="visa">VISA</option>
                <option value="meio ambiente">Meio Ambiente</option>
                <option value="agricultura">Agricultura</option>
            </select> 
            <br><btn id="busca" type="text" name="busca" placeholder="">Pesquisar<img src="img/searchicon.png"></btn>        
        </div>
    
        <div id ="resultado">
            <?php 
                  if($pesquisado && empty($resultado)){
                      echo '<div class="w3-container w3-section w3-red w3-card-24">  Resultado n�o encontrado!</p> </div>';  
                  }else{
                    echo $resultado; 
                  }
            ?>
        </div>
        <script>
        // Get the Sidenav
            var mySidenav = document.getElementById("mySidenav");

        // Get the DIV with overlay effect
            var overlayBg = document.getElementById("myOverlay");

        // Toggle between showing and hiding the sidenav, and add overlay effect
            function w3_open() {
                if (mySidenav.style.display === 'block') {
                    mySidenav.style.display = 'none';
                    overlayBg.style.display = "none";
                } else {
                    mySidenav.style.display = 'block';
                    overlayBg.style.display = "block";
                }
            }

        // Close the sidenav with the close button
            function w3_close() {
                mySidenav.style.display = "none";
                overlayBg.style.display = "none";
            }
                  
            //Metodo para recuperar as regras cadastradas para um determinado municipio
            $(document).ready(function(){ 
            $("#busca").click(function(){  
             var $cnpj = $('#cnpj');
             var valueCNPJ = $cnpj.val();
             var $nomeSecretaria = $('#regra');
             var valuenomeSec = $nomeSecretaria.val();
             //alert(valueCNPJ+valuenomeSec);
             
             $("#resultado").load("forms/pesquisaRegraPorInstituicao.php?cnpj="+encodeURIComponent(valueCNPJ)+'&regra='+encodeURIComponent(valuenomeSec));
             }); 
            });

              
        </script>

    </body>
</html> 


