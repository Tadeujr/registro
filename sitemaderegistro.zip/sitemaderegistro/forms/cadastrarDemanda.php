<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');

$resultado = '';
?>

	<br>

	<form class="w3-container">
		<h2>Cadastrar Nova Demanda</h2>
			<div class="w3-row-padding">							
					<div class="w3-half">Solicitante: <select class="w3-select w3-border" name="solicitante" id="solicitante">
						<option value="1">Usuario 01</option>
						<option value="2">Usuario 02</option>
						<option value="3">Usuario 03</option>
					</select></div> 
					<div class="w3-half">Tipo de Demanda: <select class="w3-select w3-border" name="tipoDemanda" id="tipoDemanda">
						<option value="1">Novo</option>
						<option value="2">Mensal</option>
						<option value="3">Projeto</option>
						<option value="4">SistemaS</option>						
						<option value="5">Outros</option>
					</select></div> 
					<br>Descri��o da Demanda:
					<textarea class="w3-input w3-border w3-round"></textarea>
					<div class="w3-half">
						�rea Destino: <select class="w3-select w3-border" name="area" id="area">
							<option value="1">GABINETE</option>
							<option value="2">GERAT</option>
							<option value="3">GTI</option>
							<option value="4">GPGF</option>
							<option value="5">PROCURADORIA</option>					
							<option value="10">OUTROS</option>
						</select>
					</div>					
					<br>									
					<div class="w3-half" style="padding-left: 64px; padding-right: 64px;" id="dtEntrega">
						<label>Prazo de Entrega</label> 
						<input name="data" id="data" class="w3-input w3-border w3-round gldp-el" gldp-id="calendar" autocomplete="off" readonly="" value="Clique aqui para selecionar a data" type="text" style="cursor: pointer"> 
						<br />
						<div id="calendar" gldp-el="calendar" style="width: 320px; height: 300px; position: initial; margin-bottom: 15px; margin-left: auto; margin-right: auto;"></div>
					</div>	
					<div name="dataMensal" id="dataMensal" style="visibility:hidden">Dia: <input class="w3-input w3-border w3-round" ></div>
					<br>					
					<div><input class="w3-check" id="aprovacao" type="checkbox" name="aprovacao" value="aprovado"> Solicitar Aprova��o:</div>
					<br><div id="div-aprovador" style="display:none;">Aprovador(es) <i>(para selecionar mais de um aprovador, mantenha pressionada a tecla Ctrl e clique nas op��es)</i><select class="w3-select w3-border" name="aprovador" id="aprovador" multiple="multiple">
						<option value="1">Presidente</option>
						<option value="2">Secretario</option>
						<option value="3">Gerencia GERAT</option>	
						<option value="4">Gerencia GPGF</option>
						<option value="5">Plen�rio Vogais</option>					
					</select> 					
					</div><br>
					<div class="w3-third">&nbsp;</div>
					<div class="w3-third">
						<button class="w3-btn-block w3-large w3-round w3-blue"value="Salvar">Salvar</button>
					</div>
					<div class="w3-third">&nbsp;</div>
					
				</div>	
	</form>

<script src="js/glDatePicker.js"></script>
<script>
	$('input#data').glDatePicker({
        dowNames: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        onClick: (function(el, cell, date, data) { el.val(((date.getDate() > 9) ? date.getDate() : '0' + date.getDate()) + '/' + (((date.getMonth()+1) > 9) ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1)) + '/' + date.getFullYear()); $('input#data').trigger('change'); })
    });

	//Metodo para habilitar aprovador caso a demanda necessite de aprovacao
	$("#aprovacao").click(function () {
	    if ($('#aprovacao').is(':checked')) {
	        //$("#aprovador").val($(".hidden1").val());
	        $("#div-aprovador").show();
	    } else {
	        $("#div-aprovador").val("");
	        $("#div-aprovador").hide();
	    }
	});


	//Metodo para habilitar aprovador caso a demanda mensal
	$("select#tipoDemanda").click(function () {
		var tipo = $('select#tipoDemanda').val();		
		if(tipo == '2'){
				document.getElementById('dataMensal').style.visibility='visible';
				document.getElementById('dtEntrega').style.visibility='hidden';			
			}else{
				document.getElementById('dataMensal').style.visibility='hidden';	
				document.getElementById('dtEntrega').style.visibility='visible';	
				}
	});
    
</script>


