<!DOCTYPE html>
<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/bd/bd_conveniados.php');
require_once(__ROOT__.'/util/utils.php');


$resultado = '';
if (isset($_GET["instituicao"]) and ! empty($_GET["instituicao"])) {    
    $instituicao = strtoupper(utf8_decode($_GET["instituicao"]));  
       
    $usuarios = array();
    $usuarios = pesquisaUsuariosAtivos(strtoupper($instituicao));
    $resultado = constroi_tabela($usuarios);
}

?>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" type="text/css" href="css/style.css" />

<body>

        <br>       
        
    <div class="w3-container">
            <input class="input-pesquisa" id="busca" type="text" name="busca" placeholder="Digite a Institui��o para pesquisar os usuarios...">        
        </div>
    
        <div id ="resultado">
            <?php echo $resultado; ?>
        </div>
        <script>
        // Get the Sidenav
            var mySidenav = document.getElementById("mySidenav");

        // Get the DIV with overlay effect
            var overlayBg = document.getElementById("myOverlay");

        // Toggle between showing and hiding the sidenav, and add overlay effect
            function w3_open() {
                if (mySidenav.style.display === 'block') {
                    mySidenav.style.display = 'none';
                    overlayBg.style.display = "none";
                } else {
                    mySidenav.style.display = 'block';
                    overlayBg.style.display = "block";
                }
            }

        // Close the sidenav with the close button
            function w3_close() {
                mySidenav.style.display = "none";
                overlayBg.style.display = "none";
            }
            
                            
             $("#busca").on( "keydown", function(event) {                
             if(event.which == 13) 
             var $field = $('#busca');
             var value = $field.val();               
             
             //alert(value);
             //Metodo encodeURIComponent permite adicionar parametros com espacos em branco
             $("#resultado").load("forms/pesquisaUsuarioPorInstituicao.php?instituicao="+encodeURIComponent(value));
            });
             
              
        </script>

    </body>
</html> 


