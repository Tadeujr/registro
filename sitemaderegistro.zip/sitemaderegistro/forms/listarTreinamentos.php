<?php
define ( '__ROOT__', dirname(dirname( __FILE__ )));
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once (__ROOT__ . '/util/utils.php');

$resultado = pesquisarTreinamentos();

if (empty($resultado)):
	exibirAlerta('aviso', 'N�o existem treinamentos cadastrados.'); 
else: ?>
<div class="w3-container">
	<ul class="w3-ul w3-card-4 w3-white">
<?php foreach ($resultado as $treinamento): ?>
	<?php $dataHora = new DateTime($treinamento['dataHora']); ?>
		<li class="w3-padding-16">
			<!-- <span onclick="this.parentElement.style.display='none'" class="w3-closebtn w3-padding w3-margin-right w3-medium">x</span> -->
			<img src="img/calendar.png" class="w3-left w3-circle w3-margin-right" style="width:35px">
			<span class="w3-xlarge"><?= $treinamento['local'].', '.$dataHora->format('d/m/Y').' �s '.$dataHora->format('H:i') ?></span>
			<p><b>Institui��o: </b><?= $treinamento['instituicao'] ?></p>
			<div class="row-padding">
				<div class="w3-half">
					<b>Contato(s):</b>
					<ul>
					<?php foreach ($treinamento['contatos'] as $contato): ?>
						<li><?= $contato['Nome'] ?></li>
					<?php endforeach; ?>
					</ul>
				</div>
				<div class="w3-half">
					<b>Funcion�rio(s):</b>
					<ul>
					<?php foreach ($treinamento['funcionarios'] as $funcionario): ?>
						<li><?= $funcionario['Nome'] ?></li>
					<?php endforeach; ?>
					</ul>
				</div>
			</div>
			<span class="w3-clear"></span>
			<p><b>Observa��es: </b><?= $treinamento['observacao'] ?></p>
		</li>
<?php endforeach; ?>
	</ul>
</div>
<?php endif; ?>
<br /><br />