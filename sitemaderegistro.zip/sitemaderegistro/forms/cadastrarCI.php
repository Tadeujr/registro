<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');
require_once(__ROOT__.'/bd/bd_sgi.php');

?>


</body>
</html>

	<form method="post" class="w3-container" action="controle/controle_utilidades.php?cadastrar">
		<h2>Cadastrar CI</h2>
			<div class="w3-row-padding">							
				<div class="w3-col" style="width: 100%">
					N�mero:*
					<input name="numero" id="numero" class="w3-input w3-border w3-round-large" type="text" data-validation="required" data-validation-error-msg="Por favor, preencha o nome.">
				</div>
                            <div class="w3-col" style="width: 100%">
					Assunto:*
					<input name="nome" id="nome" class="w3-input w3-border w3-round-large" type="text" data-validation="required" data-validation-error-msg="Por favor, preencha o nome.">
				</div>
			</div>			
			<div class="w3-row-padding">
				<div class="w3-third">&nbsp;</div>
				<div class="w3-third w3-padding">
					<button name="submit" id="submit" class="w3-btn-block w3-large w3-round w3-blue" value="Salvar">Salvar</button>
				</div>
				<div class="w3-third">&nbsp;</div>
			</div>	
	</form>

<script src="js/jquery.form-validator.min.js"></script>
<script src="js/jquery.form-validator.brazil.min.js"></script>
<script>
	$.validate();
</script>
