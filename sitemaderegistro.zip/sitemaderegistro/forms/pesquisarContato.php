<?php
define ( '__ROOT__', dirname ( dirname ( __FILE__ ) ) );
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once (__ROOT__ . '/util/utils.php');

$resultado = pesquisarContatos();
?>
<!--
<div class="w3-container">
	<input type="text" class="input-pesquisa" id="busca" name="busca" placeholder="Digite o nome do contato que deseja pesquisar...">
</div>
-->
<?php echo !empty($resultado) ? constroi_tabela($resultado) : exibirAlerta('aviso', 'N�o existem contatos cadastrados no sistema!'); ?>
