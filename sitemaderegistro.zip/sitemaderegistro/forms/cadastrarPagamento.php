<?php 

define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');

$resultado = '';
?>

	<br>

	<form class="w3-container">
		<h2>Cadastrar Novo Pagamento</h2>
			<div class="w3-row-padding">							
					<div class="w3-half">Solicitante: <select class="w3-select w3-border" name="solicitante" id="solicitante">
						<option value="1">Usuario 01</option>
						<option value="2">Usuario 02</option>
						<option value="3">Usuario 03</option>
					</select></div> 
					<div class="w3-half">Tipo de Demanda: <select class="w3-select w3-border" name="tipoDemanda" id="tipoDemanda">
						<option value="1">Melhoria</option>
						<option value="2">Mudan�a de Requisitos</option>
						<option value="3">Projeto</option>
					</select></div> 
					<br>Descri��o da Demanda:
					<textarea class="w3-input w3-border w3-round"></textarea>
					<div class="w3-half">
						�rea: <select class="w3-select w3-border" name="area" id="area">
							<option value="1">Regin</option>
							<option value="2">Certid�o Web</option>
							<option value="3">Site</option>
							<option value="4">Sisgerpro</option>
							<option value="5">Agendamento</option>
							<option value="6">Conveniados</option>
							<option value="7">Novo Sistema</option>
						    <option value="8">Infraestrutura</option>
							<option value="9">Suporte</option>
						</select>
					</div>
					<div class="w3-half">
						Respons�vel
						Acompanhamento: <select class="w3-select w3-border" name="responsavel" id="responsavel">
							<option value="1">Usuario 01</option>
							<option value="2">Usuario 02</option>
							<option value="3">Terceiros</option>
						</select>
					</div>
					<br>
					<div class="w3-group" style="padding-left: 64px; padding-right: 64px;">
						<label>Prazo de Entrega</label> 
						<input name="data" id="data" class="w3-input w3-border w3-round gldp-el" gldp-id="calendar" autocomplete="off" readonly="" value="Clique aqui para selecionar a data" type="text" style="cursor: pointer"> 
						<br />
						<div id="calendar" gldp-el="calendar" style="width: 320px; height: 300px; position: initial; margin-bottom: 15px; margin-left: auto; margin-right: auto;"></div>
					</div>
					<br>Situa��o: <select class="w3-select w3-border" name="situacao" id="situacao">
						<option value="1">Novo</option>
						<option value="2">Em desenvolvimento</option>
						<option value="3">Aguardando cota��o</option>
						<option value="4">Pendente</option>
						<option value="5">Finalizada</option>
					</select>
					<br>Valor Estimado: (caso terceiro)
					<input class="w3-input w3-border w3-round-large"
						type="text"> <br>Observacoes:
					<textarea class="w3-input w3-border w3-round"></textarea>
					<br>					
					<div><input class="w3-check" id="aprovacao" type="checkbox" name="aprovacao" value="aprovado"> Solicitar Aprova��o:</div>
					<br><div id="div-aprovador" style="display:none;">Aprovador(es) <i>(para selecionar mais de um aprovador, mantenha pressionada a tecla Ctrl e clique nas op��es)</i><select class="w3-select w3-border" name="aprovador" id="aprovador" multiple="multiple">
						<option value="1">Secretario</option>
						<option value="1">Gerencia GERAT</option>	
						<option value="1">Gerencia GPGF</option>					
					</select> 					
					</div><br>
					<div class="w3-third">&nbsp;</div>
					<div class="w3-third">
						<button class="w3-btn-block w3-large w3-round w3-blue"value="Salvar">Salvar</button>
					</div>
					<div class="w3-third">&nbsp;</div>
					
				</div>	
	</form>

<script src="js/glDatePicker.js"></script>
<script>
	$('input#data').glDatePicker({
        dowNames: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        onClick: (function(el, cell, date, data) { el.val(((date.getDate() > 9) ? date.getDate() : '0' + date.getDate()) + '/' + (((date.getMonth()+1) > 9) ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1)) + '/' + date.getFullYear()); $('input#data').trigger('change'); })
    });

	//Metodo para habilitar aprovador caso a demanda necessite de aprovacao
	$("#aprovacao").click(function () {
	    if ($('#aprovacao').is(':checked')) {
	        //$("#aprovador").val($(".hidden1").val());
	        $("#div-aprovador").show();
	    } else {
	        $("#div-aprovador").val("");
	        $("#div-aprovador").hide();
	    }
	});
    
</script>


