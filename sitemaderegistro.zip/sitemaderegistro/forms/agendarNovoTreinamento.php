<?php
define('__ROOT__', dirname(dirname(__FILE__)));
require_once(__ROOT__.'/bd/bd_conveniados.php');
require_once(__ROOT__.'/bd/bd_sgi.php');
require_once(__ROOT__.'/util/utils.php');

$nomesInstituicoes = pesquisaNomesInstituicao();
$contatos = pesquisarContatos();
$funcionarios = pesquisarFuncionarios();

if (empty($contatos)) {
	exibirAlerta('erro', 'Cadastre um Contato para agendar um treinamento.');
}
?>
<form class="w3-container" method="post" action="controle/controle_treinamentos.php?agendar">
	<div class="w3-row-padding">
		<div class="w3-half" style="padding-left: 64px; padding-right: 64px;">
			<div class="w3-group">
				<div>
					<label>Data</label>
					<input id="data" name="data" class="w3-input w3-border w3-round gldp-el" gldp-id="calendar" autocomplete="off" placeholder="Selecione a data no calend�rio" type="text" data-validation="required" data-validation-format="dd/mm/yyyy" data-validation-error-msg="Por favor, selecione uma data." readonly>
				</div>
				<br />
				<div id="calendar" gldp-el="calendar" style="width: 320px; height: 300px; position: initial; margin-bottom: 15px; margin-left: auto; margin-right: auto;"></div>
			</div>
			<div class="w3-group">
				<label>Hor&aacute;rio</label>
				<input id="horario" name="horario" class="w3-input w3-border w3-round" type="text" data-validation="required" data-validation-error-msg="Por favor, selecione um hor�rio.">
			</div>
		</div>
		<div class="w3-half">
			<div class="w3-group">
				<div>
					<label>Institui&ccedil;&atilde;o</label>
					<select id="instituicao" name="instituicao" class="w3-select w3-border w3-round" data-validation="required" data-validation-error-msg="Por favor, selecione uma institui��o.">
						<option value="">Selecione uma institui��o</option>
					  <?php foreach ($nomesInstituicoes as $n): ?>
	                    <option value="<?php echo $n['INSTITUICAO']; ?>"><?php echo $n['INSTITUICAO']; ?></option>
	                  <?php endforeach; ?>
					</select>
				</div>	
				
				<div>
					<label>Funcion&aacute;rio</label>
					<select id="funcionario" class="w3-select w3-border w3-round">
						<option value="">Selecione um funcion�rio</option>
					  <?php foreach ($funcionarios as $f): ?>
	                    <option value="<?php echo $f['Id']; ?>"><?php echo $f['Nome']; ?></option>
	                  <?php endforeach; ?>
					</select>
					<div id="divFuncionarios"></div>
					<input type="hidden" id="inputFuncionarios" name="funcionarios" data-validation="required" data-validation-error-msg="Por favor, selecione um funcion�rio."/>
				</div>
				
				<div>
					<label>Local</label>
					<input id="local" name="local" class="w3-input w3-border w3-round" type="text" data-validation="required" data-validation-error-msg="Por favor, preencha este campo.">
				</div>
			</div>
			<hr />
			<div class="w3-group">
				<h3>Contato(s)</h3>
				<?php if (empty($contatos)): ?>
				  <select id="contato" name="contato" class="w3-select w3-border w3-round" data-validation="required" data-validation-error-msg="Cadastre um contato antes de prosseguir.">
				  	<option value="">---</option>
				  </select>
				<?php else: ?>
				<select id="contato" class="w3-select w3-border w3-round-large">
					<option value="">Selecione um contato</option>
			 	  <?php foreach ($contatos as $c): ?>
			 	  	<option value="<?php echo $c['Id']; ?>"><?php echo $c['Nome'].', '.$c['Nome Instituicao']; ?></option>
			 	  <?php endforeach; ?>
				</select>
				<div id="divContatos"></div>
				<input type="hidden" id="inputContatos" name="contatos"  data-validation="required" data-validation-error-msg="Por favor, selecione um contato." />
				<?php endif; ?>
				
			</div>
			<div class="w3-clear"></div>
			<hr />
			<div class="w3-group">
				<label>Observa&ccedil;&otilde;es (<i><span id="maxlength">100</span></i> caracteres restantes)</label>
				<textarea class="w3-input w3-border w3-round" name="observacoes" id="observacoes" rows="5"></textarea>
			</div>
		</div>
	</div>
	<div class="w3-row-padding">
		<div class="w3-quarter">&nbsp;</div>
		<div class="w3-half">
			<button id="submit" name="submit" value="true" type="submit" class="w3-btn-block w3-large w3-round w3-blue">Agendar</button>
		</div>
		<div class="w3-quarter">&nbsp;</div>
	</div>
</form>

<br /><br />

<script src="js/glDatePicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/jquery.form-validator.min.js"></script>
<script>
	multipleSelect('contato', 'divContatos', 'inputContatos');
	multipleSelect('funcionario', 'divFuncionarios', 'inputFuncionarios');

	$('input#data').glDatePicker({
		showAlways: true,
        dowNames: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        onClick: (function(el, cell, date, data) { el.val(((date.getDate() > 9) ? date.getDate() : '0' + date.getDate()) + '/' + (((date.getMonth()+1) > 9) ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1)) + '/' + date.getFullYear()); $('input#data').trigger('change'); })
    });

    $('input#horario').timepicker({
        'timeFormat': 'H:i',
        'scrollDefault': 'now'
    });

    $('#observacoes').restrictLength($('#maxlength'));
    
    $.validate({
    	validateHiddenInputs: true
    });
</script>
