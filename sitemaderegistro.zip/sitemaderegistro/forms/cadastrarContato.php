<?php 
define('__ROOT__', dirname(dirname(__FILE__))); 
require_once(__ROOT__.'/util/utils.php');
require_once(__ROOT__.'/bd/bd_sgi.php');

$tiposInstituicao = pesquisarTiposInstituicao();
?>
	<form method="post" class="w3-container" action="controle/controle_contatos.php?cadastrar">
		<h2>Cadastrar Novo Contato</h2>
			<div class="w3-row-padding">							
				<div class="w3-col" style="width: 100%">
					Nome:*
					<input name="nome" id="nome" class="w3-input w3-border w3-round-large" type="text" data-validation="required" data-validation-error-msg="Por favor, preencha o nome.">
				</div>
			</div>
			<div class="w3-row-padding">							
				<div class="w3-third">
					Tipo �rg�o/Institui��o:*
					<select id="tipoInstituicao" name="tipoInstituicao" class="w3-select w3-border w3-round" data-validation="required" data-validation-error-msg="Por favor, selecione um tipo.">
					  	<option value="">Selecione um tipo</option>
					  <?php foreach ($tiposInstituicao as $tipo): ?>
					  	<option value="<?php echo $tipo['id']; ?>"><?php echo $tipo['nomeTipo']; ?></option>
					  <?php endforeach; ?>
					</select>
				</div>
				<div class="w3-twothird">
					Nome �rg�o/Institui��o:*
					<input name="nomeInstituicao" id="nomeInstituicao" class="w3-input w3-border w3-round-large" type="text" data-validation="required" data-validation-error-msg="Por favor, preencha este campo.">
				</div>
			</div>
			<div class="w3-row-padding">
				<div class="w3-col" style="width:100%">
					Email:*
					<input name="email" id="email" class="w3-input w3-border w3-round-large" type="text" data-validation="required email" data-validation-error-msg="Por favor, preencha com um email v�lido.">
				</div> 
			</div>
			<div class="w3-row-padding">					
				<div class="w3-col" style="width:100%">
					Telefone Comercial:*
					<input name="telefoneComercial" id="telefoneComercial" class="w3-input w3-border w3-round-large" type="text" data-validation-help="Formato (xx) xxxx xxxx" data-validation="required brphone" data-validation-error-msg="Por favor, preencha com um telefone v�lido.">
				</div>
			</div>
			<div class="w3-row-padding">
				<div class="w3-col" style="width:100%">
					Telefone Particular:
					<input name="telefoneParticular" id="telefoneParticular" class="w3-input w3-border w3-round-large" type="text" data-validation-help="Formato (xx) xxxxx xxxx" data-validation="brphone" data-validation-optional="true" data-validation-error-msg="Por favor, preencha com um telefone v�lido.">
				</div>     
			</div>
			<div class="w3-row-padding">
				<div class="w3-third">&nbsp;</div>
				<div class="w3-third w3-padding">
					<button name="submit" id="submit" class="w3-btn-block w3-large w3-round w3-blue" value="Salvar">Salvar</button>
				</div>
				<div class="w3-third">&nbsp;</div>
			</div>	
	</form>

<script src="js/jquery.form-validator.min.js"></script>
<script src="js/jquery.form-validator.brazil.min.js"></script>
<script>
	$.validate();
</script>
