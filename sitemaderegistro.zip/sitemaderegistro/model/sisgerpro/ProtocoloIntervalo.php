<?php

class ProtocoloIntervalo {
	private $id;
	private $protocolo;
	private $intervalo;
	private $idCaminho;
	private $dtOrigem;
	private $dtDestino;
	private $tempo;
	
	public function __construct() {
		$this->id = null;
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getProtocolo() {
		return $this->protocolo;
	}
	
	public function getIntervalo() {
		return $this->intervalo;
	}
	
	public function getIdCaminho() {
		return $this->idCaminho;
	}
	
	public function getDtOrigem() {
		return $this->dtOrigem;
	}
	
	public function getDtDestino() {
		return $this->dtDestino;
	}
	
	public function getTempo() {
		return $this->tempo;
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setProtocolo($protocolo) {
		$this->protocolo = $protocolo;
	}
	
	public function setIntervalo($intervalo) {
		$this->intervalo = $intervalo;
	}
	
	public function setIdCaminho($idCaminho) {
		$this->idCaminho = $idCaminho;
	}
	
	public function setDtOrigem($dtOrigem) {
		$this->dtOrigem = $dtOrigem;
	}
	
	public function setDtDestino($dtDestino) {
		$this->dtDestino = $dtDestino;
	}
	
	public function setTempo($tempo) {
		$this->tempo = $tempo;
	}
}
