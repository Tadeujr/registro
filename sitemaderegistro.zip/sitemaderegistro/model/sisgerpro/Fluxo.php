<?php

abstract class Fluxo {
	private $id;
	private $nome;
	private $dataInicio;
	private $dataFim;
	private $andamentos;
	private $intervalos;
	
	public function __construct() {
		
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getNome() {
		return $this->nome;
	}
	
	public function getDataInicio() {
		return $this->dataInicio;
	}
	
	public function getDataFim() {
		return $this->dataFim;
	}
	
	public function getAndamentos() {
		return $this->andamentos;
	}
	
	public function getIntervalos() {
		return $this->intervalos;
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setNome($nome) {
		$this->nome = $nome;
	}
	
	public function setDataInicio(DateTime $dataInicio) {
		$this->dataInicio = $dataInicio;
	}
	
	public function setDataFim(DateTime $dataFim) {
		$this->dataFim = $dataFim;
	}
	
	public function setAndamentos($andamentos) {
		$this->andamentos = $andamentos;
	}
	
	public function setIntervalos($intervalos) {
		$this->intervalos = $intervalos;
	}
	
	public abstract function pertence(Protocolo $protocolo);
}