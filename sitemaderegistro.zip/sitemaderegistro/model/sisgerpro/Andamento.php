<?php

class Andamento {
	private $id;
	private $sq;
	private $origem;
	private $destino;
	private $codDespacho;
	private $data;
	
	public function __construct($string = null) {
		if (is_string($string)) {
			$matches = array();
			// Modelo: XX-XX (XXX)
			preg_match('/([A-Z]{2})-([A-Z]{2}) \((\d{3})\)/', $string, $matches);
			if (count($matches) === 4) {
				$this->origem = $matches[1];
				$this->destino = $matches[2];
				$this->codDespacho = $matches[3];
			}	
		}
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getSq() {
		return $this->sq;
	}
	
	public function getOrigem() {
		return $this->origem;
	}
	
	public function getDestino() {
		return $this->destino;
	}
	
	public function getCodDespacho() {
		return $this->codDespacho;
	}
	
	public function getData() {
		return $this->data;
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setSq($sq) {
		$this->sq = $sq;
	}
	
	public function setOrigem($origem) {
		$this->origem = $origem;
	}
	
	public function setDestino($destino) {
		$this->destino = $destino;
	}
	
	public function setCodDespacho($codDespacho) {
		$this->codDespacho =  $codDespacho;
	}
	
	public function setData($data) {
		$this->data = $data;
	}
	
	public function equals(Andamento $outro) {
		if ($outro === null)
			return false;
		if ($outro->getOrigem() === $this->getOrigem()
			&& $outro->getDestino() === $this->getDestino()
			&& $outro->getCodDespacho() === $this->getCodDespacho())
			return true;
		return false;
	}
	
	public function __toString() {
		return $this->origem . '-' . $this->destino . ' (' . $this->codDespacho . ')';
	} 
}