<?php
class Protocolo {
	private $id;
	private $numero;
	private $andamentos;
	private $numRetorno;
	private $status;
	private $fluxo;
	private $tempos;
	
	public function __construct($nrProtocolo = null, $numRetorno = null) {
		$this->id = null;
		$this->setNumero($nrProtocolo);
		$this->setNumRetorno($numRetorno);
		$this->andamentos = array();
		$this->tempos = array();
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getNumero() {
		return $this->numero;
	}
	
	public function getAndamentos() {
		return $this->andamentos;
	}
	
	public function getNumRetorno() {
		return $this->numRetorno;
	}
	
	public function getFluxo() {
		return $this->fluxo;
	}
	
	public function getStatus() {
		return $this->status;
	}
	
	public function getTempos() {
		return $this->tempos;
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setNumero($nrProtocolo) {
		$this->numero = $nrProtocolo;
	}
		
	public function setAndamentos(array $andamentos) {
		$this->andamentos = $andamentos;
	}
	
	public function setNumRetorno($numRetorno) {
		$this->numRetorno = $numRetorno;
	}
	
	public function setFluxo($fluxo) {
		$this->fluxo = $fluxo;
	}
	
	public function setStatus($status) {
		$this->status = $status;
	}
	
	public function setTempos($tempos) {
		$this->tempos = $tempos;
	}
	
	public function addAndamento($andamento) {
		$this->andamentos[] = $andamento;
	}
	
	public function addTempo($tempo) {
		$this->tempos[] = $tempo;
	}
	
	public function getAndamento($i) {
		return (($i >= 0 && $i < count($this->andamentos)) ? $this->andamentos[$i] : null);
	}
	
	public function __toString() {
		return $this->numero . " (". $this->numRetorno . ")";
	}
}