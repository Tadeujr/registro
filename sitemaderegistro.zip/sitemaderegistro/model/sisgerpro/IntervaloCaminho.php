<?php

class IntervaloCaminho {
	private $id;
	private $andamentoOrigem;
	private $andamentoDestino;
	private $prioridade;
	
	public function __construct() {
		
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getAndamentoOrigem() {
		return $this->andamentoOrigem;
	}
	
	public function getAndamentoDestino() {
		return $this->andamentoDestino;
	}
	
	public function getPrioridade() {
		return $this->prioridade;
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setAndamentoOrigem($andamentoOrigem) {
		$this->andamentoOrigem = $andamentoOrigem;
	}
	
	public function setAndamentoDestino($andamentoDestino) {
		$this->andamentoDestino = $andamentoDestino;
	}
	
	public function setPrioridade($prioridade) {
		$this->prioridade = $prioridade;
	}
	
}
