<?php
define('__ROOT__', dirname(__FILE__));
require_once __ROOT__.'/bd/bd_sisgerpro.php';
require_once __ROOT__.'/bd/bd_siarco.php';
require_once __ROOT__.'/model/sisgerpro/DateIntervalFunctions.php';

class Analisador {
	
	public static function analisarPeriodo(DateTime $dataIni, DateTime $dataFim) {
		// Lista os fluxos padrão do sistema
		$fluxos = listarFluxos();
		// Busca os protocolos daquele período no Siarco
		$protocolos = buscarAndamentosSisgerpro($dataIni, $dataFim);
		
		$i = 0;
		foreach ($protocolos as $i => $protocolo) {
			buscarProtocolo($protocolo);
			
			// Se o protocolo já tem um ID, ou seja, já existe no Sisgerpro
			if ($protocolo->getId() !== null) {
				// Se seu status for "Em tramitação"
				if ($protocolo->getStatus() === 'TM') {
					self::determinarFluxo($protocolo, $fluxos);
					if (null !== $protocolo->getFluxo()) {
						self::analisarTempos($protocolo);
						self::definirStatus($protocolo);
						salvarTempos($protocolo);
					}
				}
			}
			// Se o protocolo ainda não tem um ID, ou seja, não existe no Sisgerpro
			else {
				self::determinarFluxo($protocolo, $fluxos);
				if (null !== $protocolo->getFluxo()) {
					/*
					--------------------------------------------------------------------------------
					 Foram detectados que cerca de 40% dos protocolos não seguem o andamento padrão
					 do fluxo ao qual pertencem. Por este motivo, a análise do caminho permanece
					 inativada no momento
					-------------------------------------------------------------------------------- 
					if (! self::analisarAndamentos($protocolo)) {
						self::colocarEmObservacao($protocolo, "Andamento inválido");
						continue;
					}
					*/
					self::analisarTempos($protocolo);
					self::definirStatus($protocolo);
					salvarTempos($protocolo);
				}
				else {
					// Fluxo não definido, entrada errada, colocar em observação
					self::colocarEmObservacao($protocolo, "");
				}
			}
		}
		return $protocolos;
	}
		
	public static function determinarFluxo($protocolo, $fluxos) {			
		foreach ($fluxos as $fluxo) {
			if ($fluxo->pertence($protocolo)) {
				$protocolo->setFluxo($fluxo);
				return $fluxo;
			}
		}
		$protocolo->setFluxo(null);
		return null;
	}
	
	private static function analisarAndamentos($protocolo) {
		$andamentos = $protocolo->getAndamentos();
		$grafo = $protocolo->getFluxo()->getAndamentos();
		$n = count($andamentos);

		for ($i = 1; $i < $n; $i++) {
			$a = $protocolo->getAndamento($i - 1);
			$b = $protocolo->getAndamento($i);
			if (!$grafo->existeConexao($a, $b)) {
				return false;
			}
		}
		return true;
	}
	
	public static function analisarTempos($protocolo) {
		// Obtem os andamentos do protocolo
		$andamentos = $protocolo->getAndamentos();
		$numAndamentos = count($andamentos);
		
		// Obtem o fluxo ao qual o protocolo pertence
		$fluxo = $protocolo->getFluxo();
		
		// Obtem os tempos do fluxo ao qual o protocolo pertence
		$intervalos = $fluxo->getIntervalos();

		// Para cada intervalo
		foreach ($intervalos as $intervalo) {			
			$caminhos = $intervalo->getCaminhos();
			$idCaminho = null;
			$diferenca = null;
			
			// Para cada caminho no intervalo
			foreach ($caminhos as $caminho) {
				// Procura o andamento que bate na origem do caminho
				$andamentoOrigem = null;
				for ($i = 0; $i < $numAndamentos; $i++) {
					if ($andamentos[$i]->equals($caminho->getAndamentoOrigem())) {
						$andamentoOrigem = $andamentos[$i];
						break;
					}
				}
				
				// Caso tenha esse andamento, procura, a partir do próximo, o destino do caminho
				$andamentoDestino = null;
				if ($andamentoOrigem !== null) {
					for ($j = ($i + 1); $j < $numAndamentos; $j++) {
						if ($andamentos[$j]->equals($caminho->getAndamentoDestino())) {
							$andamentoDestino = $andamentos[$j];
							break;
						} 
					}
				}
				// Caso não tenha esse andamento (de origem), procura no próximo caminho
				else continue;
				
				// Caso tenha encontrado ambos destino e origem
				if ($andamentoDestino !== null) {
					// Calcula a diferenca em horas uteis
					$diferenca = DateIntervalFunctions::calcularHorasUteis($andamentoOrigem->getData(), $andamentoDestino->getData());
					if ($diferenca === null) {
						self::colocarEmObservacao($protocolo, "");	
					}
					else {
						$idCaminho = $caminho->getId();
					}
					break;
				}
				// Caso tenha a origem mas não o destino, procura no próximo caminho
				else continue;
			}
			
			$protIntervalo = new ProtocoloIntervalo();
			$protIntervalo->setProtocolo($protocolo->getNumero());
			$protIntervalo->setIntervalo($intervalo);
			$protIntervalo->setIdCaminho($idCaminho);
			$protIntervalo->setTempo($diferenca);
			if (null !== $diferenca) {
				$protIntervalo->setDtOrigem($andamentoOrigem->getData());
				$protIntervalo->setDtDestino($andamentoDestino->getData());
			}
			
			$protocolo->addTempo($protIntervalo);
		}
	}
	
	public static function definirStatus($protocolo) {
		$andamentos = $protocolo->getAndamentos();
		$tempos = $protocolo->getTempos();
		
		$tempos = $tempos ?: array();
				
		// Detecta se é EX
		foreach ($andamentos as $andamento) {
			if ($andamento->getDestino() == "EX" && $andamento->getCodDespacho() == "005") {
				$protocolo->setStatus('EX');
				return;
			}
		}
		
		// Detecta se é DBEX
		/* Desativado no momento. Verificar situação RF-EX como último andamento dos protocolos no fluxo DG
		foreach ($andamentos as $andamento) {
			if ($andamento->getOrigem() == "RF" && $andamento->getDestino() == "EX" && $andamento->getCodDespacho() == "001") {
				$protocolo->setStatus('DBEX');
				return;
			}
		}
		*/
		
		// Detecta se é OK
		$entregueCliente = false;
		foreach ($andamentos as $andamento) {
			if ($andamento->getDestino() == "CL") {
				$entregueCliente = true;
			}
		}
		if ($entregueCliente) {
			$n = count($tempos);
			if (!empty($tempos) && $tempos[$n - 1]->getTempo() !== null) {
				$protocolo->setStatus('OK');
				return;
			}
		}
		
		// Default: TM (em tramitação)
		$protocolo->setStatus('TM');
	}
	
	private static function colocarEmObservacao($protocolo, $motivo) {
		
	}
	
}
