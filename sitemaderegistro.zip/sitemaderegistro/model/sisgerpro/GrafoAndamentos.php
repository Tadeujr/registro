<?php

class GrafoAndamentos {
	private $conexoes;
	
	public function __construct() {
		$conexoes = array();
	}
	
	public function addConexao(Andamento $a, Andamento $b) {
		$id = $a->getId();
		if (! ($this->contem($a))) {
			$this->conexoes[$id] = array('andamento' => $a, 'proximos' => array());
		}
		$this->conexoes[$id]['proximos'][] = $b;
	}
	
	public function existeConexao(Andamento $a, Andamento $b) {
		if ($this->contem($a)) {
			$id = $a->getId();
			$proximos = $this->conexoes[$id]['proximos'];
			foreach ($proximos as $prox) {
				if ($prox->getId() == $b->getId()) {
					return true;
				}
			}
		}
		return false;
	}
	
	public function contem(Andamento $a) {
		return isset($this->conexoes[$a->getId()]);
	}
	
	public function imprimir() {
		echo '<pre>';
		foreach ($this->conexoes as $id => $conexao) {
			echo 'ID '.$id.' ';
			$a = $conexao['andamento'];
			if ($id !== 0)
				echo 'Andamento '.$a->getOrigem().'-'.$a->getDestino().' ('.$a->getCodDespacho().')';
			echo "\n";
			echo 'Proximos:'."\n";
			foreach ($conexao['proximos'] as $prox) {
				echo '    '.$prox->getOrigem().'-'.$prox->getDestino().' ('.$prox->getCodDespacho().')'."\n";
			}
			echo "\n";
		}
		echo '</pre>';
	}
}