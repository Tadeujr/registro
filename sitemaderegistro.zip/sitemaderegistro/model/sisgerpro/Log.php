<?php

class Log {
	
}
