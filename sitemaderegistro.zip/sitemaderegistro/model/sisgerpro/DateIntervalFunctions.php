<?php

class DateIntervalFunctions {

	public static function intervalToSeconds($interval) {
		return date_create('@0')->add($interval)->getTimestamp();
	}
	
	public static function secondsToInterval($seconds) {
		return date_create('@0')->diff(date_create('@0')->setTimestamp($seconds));
	}
	
	public static function addInterval($a, $b) {
		return self::secondsToInterval(self::intervalToSeconds($a) + self::intervalToSeconds($b));
	}
	
	public static function subInterval($a, $b) {
		return self::secondsToInterval(self::intervalToSeconds($a) - self::intervalToSeconds($b));
	}
	
	public static function calcularHorasUteis($dtOrigem, $dtDestino, $feriados = array()) {
		$semanaDoAno = array('origem' => intval($dtOrigem->format('W')), 'destino' => intval($dtDestino->format('W')));
		$diaDaSemana = array('origem' => intval($dtOrigem->format('w')), 'destino' => intval($dtDestino->format('w')));
		
		$mesmaSemana = (($semanaDoAno['destino'] - $semanaDoAno['origem']) === 0);
		$mesmoDia = $mesmaSemana && (($diaDaSemana['destino'] - $diaDaSemana['origem']) === 0);
			
		if ($mesmoDia) {
			$diferenca = $dtOrigem->diff($dtDestino);
		}
		else if ($mesmaSemana) {
			$diferenca = $dtOrigem->diff($dtDestino);
			
			$dias = $diaDaSemana['destino'] - $diaDaSemana['origem'];
			$horas = 14 * $dias; // São 14 horas entre as 18h do dia anterior e 08h do dia seguinte
			try {
				$horas = new DateInterval('PT'.$horas.'H');
			} catch (Exception $ex) {
				return null;
			}
			
			$diferenca = self::subInterval($diferenca, $horas);
		}
		else {
			$diferenca = $dtOrigem->diff($dtDestino);
			
			$semanas = $semanaDoAno['destino'] - $semanaDoAno['origem'];
			$horas = 48 * $semanas; // São 48 horas entre cada semana
			$horas += 14 * (5 - ($diaDaSemana['origem'] - $diaDaSemana['destino']));
			
			try {
				$horas = new DateInterval('PT'.$horas.'H');
			} catch (Exception $ex) {
				return null;
			}
			
			$diferenca = self::subInterval($diferenca, $horas);
		}
		
		return $diferenca;
	}
	
}
