<?php

class FluxoProcessoPapel extends Fluxo {
	public function pertence(Protocolo $protocolo) {
		$andamento0 = $protocolo->getAndamento(0);
		$andamento1 = $protocolo->getAndamento(1);
		
		if ($andamento0 && $andamento0->__toString() === 'PR-IN (001)')
			return true;
		if ($andamento0 && $andamento0->__toString() === 'PR-PR (001)' && $andamento1 && $andamento1->__toString() == 'PR-IN (001)')
			return true;
		
		return false;
	}
}
