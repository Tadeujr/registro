<?php

require_once dirname(__FILE__) . '/IntervaloCaminho.php';

class Intervalo {
	private $descricao;
	private $caminhos;
	
	public function __construct__() {
		$this->caminhos = array();
	}
	
	public function getDescricao() {
		return $this->descricao;
	}
	
	public function getCaminhos() {
		return $this->caminhos;
	}
	
	public function setDescricao($descricao) {
		$this->descricao = $descricao;
	}
	
	public function setCaminhos($caminhos) {
		$this->caminhos = $caminhos;
	}
	
	public function addCaminho($id, $andamentoOrigem, $andamentoDestino, $prioridade) {
		$caminho = new IntervaloCaminho();
		$caminho->setId($id);
		$caminho->setAndamentoOrigem($andamentoOrigem);
		$caminho->setAndamentoDestino($andamentoDestino);
		$caminho->setPrioridade($prioridade);
		
		$this->caminhos[] = $caminho;
	}
	
	public function getCaminhosByOrigem($andamentoOrigem) {
		$caminhos = array();
		foreach ($this->caminhos as $caminho)
			if ($andamentoOrigem->equals($caminho->getAndamentoOrigem()))
				$caminhos[] = $caminho;
		return $caminhos;
	}
	
}
